taskset -c 10,11 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli

#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/e9-lut-75c-probe"
out="$base/native-cuda-cli"
target="$root/pancake/target/e9-lut-release"
mkdir -p "$out"
test -z "$(git status --porcelain=v1)"
test "$(git rev-parse HEAD)" = "$(cat "$base/candidate-source.txt")"
for baseline in "$base"/baseline/*.f32le; do
    cmp "$baseline" "$base/candidate/${baseline##*/}"
done
cmp "$base/baseline/cpu-semantics.txt" "$base/candidate/cpu-semantics.txt"
sha256sum "$root/pancake/Cargo.lock" > "$out/lock.sha256"
git rev-parse HEAD 'HEAD^{tree}' > "$out/git-identity.txt"
rustc +1.100.0 -Vv > "$out/rustc.txt"
export CUDARC_CUDA_VERSION=12050
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$target"
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
sha256sum "$RUSTC_WRAPPER" > "$out/rustc-wrapper.sha256"
cd "$root/pancake"
cmd=(taskset --cpu-list 12,13 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli --features cubecl/cuda)
printf '%s\n' "$PWD" "CUDARC_CUDA_VERSION=$CUDARC_CUDA_VERSION CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS CARGO_INCREMENTAL=$CARGO_INCREMENTAL CARGO_TARGET_DIR=$CARGO_TARGET_DIR RUSTC_WRAPPER=$RUSTC_WRAPPER" > "$out/build.command"
printf '%q ' "${cmd[@]}" >> "$out/build.command"
printf '\n' >> "$out/build.command"
date -u +%FT%TZ > "$out/start-utc.txt"
/usr/bin/time --verbose --output="$out/build-resource.txt" "${cmd[@]}" > "$out/build.log" 2>&1
date -u +%FT%TZ > "$out/end-utc.txt"
elf="$target/release/pancake-cli"
sha256sum "$elf" > "$out/pancake-cli.sha256"
readelf -n "$elf" > "$out/elf-notes.txt"
ldd "$elf" > "$out/ldd.txt"
nm --defined-only --demangle "$elf" | awk '/cubecl_cuda/ { cuda++ } /[Nn][Vv][Pp][Tt][Xx]/ { nvptx++ } END { print "native CUDA symbol matches", cuda; print "NVPTX symbol matches", nvptx; exit !(cuda > 0 && nvptx > 0) }' > "$out/link-witness.txt"
test -z "$(git status --porcelain=v1)"

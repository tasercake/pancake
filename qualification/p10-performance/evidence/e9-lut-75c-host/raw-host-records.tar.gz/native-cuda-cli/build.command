/tmp/pancake-worktrees.t3paqgWM/e9-persistence-review/pancake
CUDARC_CUDA_VERSION=12050 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/tmp/pancake-worktrees.t3paqgWM/e9-persistence-review/pancake/target/e9-lut-release RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
taskset --cpu-list 12\,13 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli --features cubecl/cuda 

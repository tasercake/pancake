#!/usr/bin/env bash
set -euo pipefail
root=$PWD
base="$root/artifacts/e9-lut-75c-probe"
role=${1:?Pass baseline or candidate}
case "$role" in
    baseline|candidate) ;;
    *) exit 2 ;;
esac
record="$base/$role"
export CARGO_TARGET_DIR="$root/pancake/target/e9-lut-release"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export CUDARC_CUDA_VERSION=12050
recorded_source=$(cat "$base/$role-source.txt")
test "$(git rev-parse HEAD)" = "$recorded_source"
test -z "$(git status --porcelain=v1)"
git rev-parse 'HEAD^{tree}' > "$base/$role-tree.txt"
sha256sum pancake/Cargo.lock > "$record/lock.sha256"
sha256sum "${base}/native_cpu_probe_${role}.rs" > "$record/harness.sha256"
registration=pancake/src/registration/spectral.rs
trap 'git restore --worktree "$registration"' EXIT
printf '\n#[cfg(test)]\n#[path = "../../../artifacts/e9-lut-75c-probe/native_cpu_probe_%s.rs"]\nmod native_cpu_probe;\n' "$role" >> "$registration"
git diff -- "$registration" > "$record/test-only.patch"
sha256sum "$registration" > "$record/linked-source.sha256"
command=(cargo +1.100.0 rustc --locked --offline --release --lib --crate-type bin -p pancake
    --features cubecl/cuda --message-format json -- --test)
printf '%q ' "${command[@]}" > "$record/build.command"
printf '\n' >> "$record/build.command"
(cd pancake && /usr/bin/time --verbose --output="$record/build-resource.txt" \
    "${command[@]}") > "$record/build.jsonl" 2> "$record/build.log"
bin=$(jq -er 'select(.reason=="compiler-artifact" and .target.name=="pancake") | .filenames[] | select(endswith("/pancake"))' "$record/build.jsonl")
test -x "$bin"
sha256sum "$bin" > "$record/test-binary.sha256"
command=(env PANCAKE_COLD_PROBE_OUTPUT="$record" "$bin"
    registration::spectral::native_cpu_probe::registration_cpu_surface_and_counts --exact)
printf '%q ' "${command[@]}" > "$record/test.command"
printf '\n' >> "$record/test.command"
"${command[@]}" > "$record/test.log" 2>&1
rg -q '^test result: ok\. 1 passed;' "$record/test.log"
sha256sum "$record/"*.f32le "$record/cpu-semantics.txt" > "$record/test-output.sha256"
cat "$record/test.log"

cargo +1.100.0 rustc --locked --offline --release --lib --crate-type bin -p pancake --features cubecl/cuda --message-format json -- --test 

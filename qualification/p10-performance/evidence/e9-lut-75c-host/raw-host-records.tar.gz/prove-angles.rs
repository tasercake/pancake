fn main() {
    let mut terms = 0_u32;
    for side in [64_u16, 128] {
        for direction in [-1.0_f32, 1.0] {
            let mut half = 1_u16;
            while half < side {
                let stride = side / (2 * half);
                for offset in 0..half {
                    let before = direction * std::f32::consts::PI * f32::from(offset) / f32::from(half);
                    let table_index = offset * stride;
                    let after = direction * std::f32::consts::PI * f32::from(table_index) / f32::from(side / 2);
                    assert_eq!(before.to_bits(), after.to_bits(), "{side} {direction} {half} {offset}");
                    terms += 1;
                }
                half *= 2;
            }
        }
    }
    println!("{terms} bit-identical f32 angles across both directions and all radix-two stages for sides 64 and 128");
}

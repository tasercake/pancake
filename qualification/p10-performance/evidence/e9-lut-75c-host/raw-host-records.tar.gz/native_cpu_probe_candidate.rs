//! Test-only parity capture for the real checked CPU registration kernels.

use std::io::Write as _;
use std::sync::{Arc, Mutex};

use cubecl::logging::{LaunchObservation, LaunchObserver};
use cubecl::prelude::CubeElement as _;

use super::super::geometry::{Affine, Extent};
use super::super::kernels::{Pair, read};
use super::{forward, transform};

/// Capture the names of commands issued while a true CPU result is computed.
#[derive(Default, Debug)]
struct KernelCounts(Mutex<Vec<&'static str>>);

impl LaunchObserver for KernelCounts {
    fn launched(&self, kernel: &'static str) {
        if let Ok(mut commands) = self.0.lock() {
            commands.push(kernel);
        }
    }
}

/// Save finite completed surface bits, coarse decisions and scored affine maps.
/// # Errors
/// Returns initialization, fixture, readback, launch or evidence errors.
#[test]
fn registration_cpu_surface_and_counts() -> Result<(), String> {
    let folder = std::path::PathBuf::from(
        std::env::var_os("PANCAKE_COLD_PROBE_OUTPUT").ok_or("CPU output path")?,
    );
    std::fs::create_dir_all(&folder).map_err(|error| error.to_string())?;
    let mut all = std::fs::File::create(folder.join("cpu-semantics.txt"))
        .map_err(|error| error.to_string())?;
    let device = cubecl::Device::cpu().map_err(|error| error.to_string())?;
    let client = device.client();
    for (width, height, side) in [(83_usize, 73_usize, 64_usize), (163, 139, 128)] {
        let extent = Extent::new(width, height)?;
        for (kind, shift_x, shift_y) in
            [("identity", 0_i16, 0_i16), ("shift", 7, -6), ("flat", 0, 0)]
        {
            let texel = |index: usize| -> Result<f32, String> {
                let col = i32::try_from(index % width).map_err(|error| error.to_string())?;
                let row = i32::try_from(index / width).map_err(|error| error.to_string())?;
                let val = (col * col * 17 + row * row * 13 + col * row * 19 + col + row * 7)
                    .rem_euclid(251);
                let val = u16::try_from(val).map_err(|error| error.to_string())?;
                Ok(f32::from(val) / 250.0)
            };
            let count = extent.area()?;
            let reference = if kind == "flat" {
                vec![0.5_f32; count]
            } else {
                (0..count).map(texel).collect::<Result<Vec<_>, String>>()?
            };
            let moving = (0..count)
                .map(|index| {
                    let col = (index % width)
                        .saturating_add_signed(isize::from(shift_x))
                        .min(width.saturating_sub(1));
                    let row = (index / width)
                        .saturating_add_signed(isize::from(shift_y))
                        .min(height.saturating_sub(1));
                    reference
                        .get(row.saturating_mul(width).saturating_add(col))
                        .copied()
                        .ok_or("missing source sample")
                })
                .collect::<Result<Vec<_>, _>>()?;
            let pair = Pair::new(&device, &reference, &moving, extent);
            let observer = Arc::new(KernelCounts::default());
            let observing = LaunchObservation::new(observer.clone());
            let coarse = pair.spectral_seed()?;
            drop(observing);
            let counts = observer.0.lock().map_err(|error| error.to_string())?;
            let count_name = |name| counts.iter().filter(|kernel| kernel.contains(name)).count();
            let window = count_name("window_luma");
            let fft = count_name("fft_lines");
            let cross = count_name("cross_phase");
            if (window, fft, cross, counts.len()) != (2, 6, 1, 9) {
                return Err(format!("unexpected phase launch counts {counts:?}"));
            }
            if kind == "flat" && coarse.is_some() {
                return Err(format!(
                    "flat input produced an unambiguous seed {coarse:?}"
                ));
            }
            let map = Affine::from_matrix([
                [1.0, 0.0, -f32::from(shift_x)],
                [0.0, 1.0, -f32::from(shift_y)],
            ])?;
            let scores = pair.correlation(&[Affine::IDENTITY, map], 1)?;
            let score_bits = scores.into_iter().map(f32::to_bits).collect::<Vec<_>>();
            let coarse_bits = coarse.map(|coordinates| coordinates.map(f32::to_bits));
            writeln!(all, "{side} {kind} coarse={coarse_bits:?} score={score_bits:?} launches={window},{fft},{cross}")
                .map_err(|error| error.to_string())?;
            let uploaded = cubecl::std::tensor::TensorHandle::new_contiguous(
                [count],
                client.create_from_slice(f32::as_bytes(&moving)),
                f32::cube_type(),
            );
            let complex = side.saturating_mul(side).saturating_mul(2);
            let twiddles = cubecl::std::tensor::TensorHandle::empty(
                &client, [side.saturating_mul(2)], f32::cube_type(),
            );
            let forward_surface = forward(&client, &uploaded, extent, side, complex, &twiddles, true);
            let surface = transform(&client, forward_surface, side, complex, &twiddles, true);
            let bits = read(&client, surface, complex)?
                .into_iter()
                .flat_map(|sample| sample.to_bits().to_le_bytes())
                .collect::<Vec<_>>();
            std::fs::write(folder.join(format!("{side}-{kind}.f32le")), bits)
                .map_err(|error| error.to_string())?;
        }
    }
    Ok(())
}

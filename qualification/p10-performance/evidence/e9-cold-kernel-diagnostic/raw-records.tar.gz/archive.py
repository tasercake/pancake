"""Preserve original per-process compiler and exact CPU parity witnesses."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile

record = Path(sys.argv[1])
output = Path(sys.argv[2])
output.mkdir(parents=True, exist_ok=True)
audit = json.loads((record / 'audit.json').read_text())
audit['experimental_source'] = (record / 'experiment-revision.txt').read_text().strip()
files = {
    name: path for path in record.iterdir() if path.is_file()
    and path.suffix in {'.log','.txt','.json','.rs','.patch','.sha256','.sh','.command','.py'}
    and (name := path.name) not in {'cold_probe.rs', 'native_cpu_probe.rs'}
}
for variant in ('baseline', 'candidate'):
    prefix = record / variant
    for path in prefix.rglob('*'):
        if path.is_file():
            files[path.relative_to(record).as_posix()] = path
    cpu = record / f'{variant}-cpu'
    for path in cpu.glob('*'):
        if path.is_file():
            files[path.relative_to(record).as_posix()] = path
for name in ('audit.json','cleanup.log','witness.sha256', 'pinned-optimizer-source.sha256'):
    assert name in files, name
archive = output / 'raw-records.tar.gz'
manifest = {}
with archive.open('wb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|') as tar:
        for name, path in sorted(files.items()):
            contents = path.read_bytes()
            manifest[name] = {'bytes': len(contents), 'sha256': sha256(contents).hexdigest()}
            tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, mode='r:gz') as tar:
    assert set(tar.getnames()) == set(manifest)
    for entry in tar.getmembers():
        assert entry.isfile()
        content = tar.extractfile(entry).read()
        assert manifest[entry.name] == {'bytes': len(content), 'sha256': sha256(content).hexdigest()}
audit['raw_archive'] = {
    'archive': archive.name,
    'sha256': sha256(archive.read_bytes()).hexdigest(),
    'files': manifest,
}
(output / 'summary.json').write_text(json.dumps(audit, indent=2) + '\n')
print(f"{len(manifest)} rehashed raw files with archive SHA-256 {audit['raw_archive']['sha256']}")

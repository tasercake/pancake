; ModuleID = 'kernel'
source_filename = "kernel"
target triple = "nvptx64-nvidia-cuda"

define ptx_kernel void @window_luma_7c652f0e(ptr addrspace(1) noalias readonly %0, ptr addrspace(1) noalias %1, ptr addrspace(1) noalias %2, ptr addrspace(1) noalias readonly %3, ptr noalias readonly byval([88 x i8]) align 8 %4) #0 {
entry_block2v1:
  %v563 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v564 = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %v565 = call i32 @llvm.nvvm.read.ptx.sreg.tid.z()
  %v566 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v567 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v568 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %v569 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %v570 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.y()
  %v571 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.z()
  %v572 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %v647 = mul i32 %v564, 32
  %v648 = add i32 %v563, %v647
  %v650 = mul i32 %v565, 32
  %v652 = mul i32 %v650, 8
  %v653 = add i32 %v648, %v652
  %v654 = mul i32 %v568, %v569
  %v655 = mul i32 %v654, %v570
  %v656 = mul i32 %v567, %v569
  %v657 = add i32 %v655, %v656
  %v658 = add i32 %v657, %v566
  %v660 = mul i32 %v658, 256
  %v661 = add i32 %v660, %v653
  %v665 = getelementptr inbounds nuw i32, ptr %4, i64 6
  %v666 = load i32, ptr %v665, align 4
  %v669 = getelementptr inbounds nuw i32, ptr %4, i64 7
  %v670 = load i32, ptr %v669, align 4
  %v673 = getelementptr inbounds nuw i32, ptr %4, i64 8
  %v674 = load i32, ptr %v673, align 4
  %v677 = getelementptr inbounds nuw i32, ptr %4, i64 10
  %v678 = load i32, ptr %v677, align 4
  %v681 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v682 = udiv i32 %v674, %v681
  %v684 = icmp ne i32 %v678, 0
  %v685 = icmp ult i32 %v661, %v682
  %v686 = and i1 %v684, %v685
  br i1 %v686, label %then_block3v1, label %else_block4v1

then_block3v1:                                    ; preds = %entry_block2v1
  %v688 = mul i32 %v661, 4
  %v689 = uitofp i32 %v682 to float
  %v690 = uitofp i32 %v661 to float
  %v692 = fmul contract float f0x40490FDB, %v690
  %v693 = fneg float %v692
  %v694 = fdiv float %v693, %v689
  %v695 = fdiv float %v692, %v689
  %v696 = call float @llvm.cos.f32(float %v694)
  %v697 = zext i32 %v688 to i64
  %v698 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v697
  store float %v696, ptr addrspace(1) %v698, align 4
  %v699 = call float @llvm.sin.f32(float %v694)
  %v701 = add i32 %v688, 1
  %v702 = zext i32 %v701 to i64
  %v703 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v702
  store float %v699, ptr addrspace(1) %v703, align 4
  %v704 = call float @llvm.cos.f32(float %v695)
  %v705 = add i32 %v688, 2
  %v706 = zext i32 %v705 to i64
  %v707 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v706
  store float %v704, ptr addrspace(1) %v707, align 4
  %v708 = call float @llvm.sin.f32(float %v695)
  %v710 = add i32 %v688, 3
  %v711 = zext i32 %v710 to i64
  %v712 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v711
  store float %v708, ptr addrspace(1) %v712, align 4
  br label %if_merge_block7v1

else_block4v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block7v1

if_merge_block7v1:                                ; preds = %else_block4v1, %then_block3v1
  %v714 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v715 = udiv i32 %v661, %v714
  %v717 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v718 = urem i32 %v661, %v717
  %v719 = icmp eq i32 %v718, 0
  br i1 %v719, label %then_block5v1, label %else_block6v1

then_block5v1:                                    ; preds = %if_merge_block7v1
  %v720 = uitofp i32 %v674 to float
  %v722 = call i32 @llvm.umax.i32(i32 %v674, i32 1)
  %v723 = urem i32 %v715, %v722
  %v724 = uitofp i32 %v723 to float
  %v726 = fadd contract float %v724, 5.000000e-01
  %v728 = call i32 @llvm.umax.i32(i32 %v674, i32 1)
  %v729 = udiv i32 %v715, %v728
  %v730 = uitofp i32 %v729 to float
  %v731 = fadd contract float %v730, 5.000000e-01
  %v732 = uitofp i32 %v666 to float
  %v733 = fdiv float %v732, %v720
  %v734 = uitofp i32 %v670 to float
  %v735 = fdiv float %v734, %v720
  %v737 = call float @llvm.fmuladd.f32(float %v726, float %v733, float -5.000000e-01)
  %v739 = call float @llvm.fmuladd.f32(float %v731, float %v735, float -5.000000e-01)
  %v741 = sub i32 %v666, 1
  %v742 = sub i32 %v670, 1
  %v744 = call float @llvm.maxnum.f32(float %v737, float 0.000000e+00)
  %v745 = uitofp i32 %v741 to float
  %v746 = call float @llvm.minnum.f32(float %v744, float %v745)
  %v747 = call float @llvm.maxnum.f32(float %v739, float 0.000000e+00)
  %v748 = uitofp i32 %v742 to float
  %v749 = call float @llvm.minnum.f32(float %v747, float %v748)
  %v750 = fptoui float %v746 to i32
  %v751 = fptoui float %v749 to i32
  %v752 = add i32 %v750, 1
  %v753 = call i32 @llvm.umin.i32(i32 %v752, i32 %v741)
  %v754 = add i32 %v751, 1
  %v755 = call i32 @llvm.umin.i32(i32 %v754, i32 %v742)
  %v756 = uitofp i32 %v750 to float
  %v757 = fsub contract float %v746, %v756
  %v758 = uitofp i32 %v751 to float
  %v759 = fsub contract float %v749, %v758
  %v760 = mul i32 %v751, %v666
  %v761 = add i32 %v760, %v750
  %v762 = zext i32 %v761 to i64
  %v763 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v762
  %v764 = load float, ptr addrspace(1) %v763, align 4
  %v765 = add i32 %v760, %v753
  %v766 = zext i32 %v765 to i64
  %v767 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v766
  %v768 = load float, ptr addrspace(1) %v767, align 4
  %v769 = mul i32 %v755, %v666
  %v770 = add i32 %v769, %v750
  %v771 = zext i32 %v770 to i64
  %v772 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v771
  %v773 = load float, ptr addrspace(1) %v772, align 4
  %v774 = add i32 %v769, %v753
  %v775 = zext i32 %v774 to i64
  %v776 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v775
  %v777 = load float, ptr addrspace(1) %v776, align 4
  %v779 = fsub contract float 1.000000e+00, %v757
  %v780 = fmul contract float %v757, %v768
  %v781 = call float @llvm.fmuladd.f32(float %v779, float %v764, float %v780)
  %v782 = fmul contract float %v757, %v777
  %v783 = call float @llvm.fmuladd.f32(float %v779, float %v773, float %v782)
  %v784 = fsub contract float 1.000000e+00, %v759
  %v785 = fmul contract float %v759, %v783
  %v786 = call float @llvm.fmuladd.f32(float %v784, float %v781, float %v785)
  %v787 = fsub contract float %v737, %v733
  %v788 = call float @llvm.maxnum.f32(float %v787, float 0.000000e+00)
  %v789 = call float @llvm.minnum.f32(float %v788, float %v745)
  %v790 = fptoui float %v789 to i32
  %v791 = add i32 %v790, 1
  %v792 = call i32 @llvm.umin.i32(i32 %v791, i32 %v741)
  %v793 = uitofp i32 %v790 to float
  %v794 = fsub contract float %v789, %v793
  %v795 = add i32 %v760, %v790
  %v796 = zext i32 %v795 to i64
  %v797 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v796
  %v798 = load float, ptr addrspace(1) %v797, align 4
  %v799 = add i32 %v760, %v792
  %v800 = zext i32 %v799 to i64
  %v801 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v800
  %v802 = load float, ptr addrspace(1) %v801, align 4
  %v803 = add i32 %v769, %v790
  %v804 = zext i32 %v803 to i64
  %v805 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v804
  %v806 = load float, ptr addrspace(1) %v805, align 4
  %v807 = add i32 %v769, %v792
  %v808 = zext i32 %v807 to i64
  %v809 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v808
  %v810 = load float, ptr addrspace(1) %v809, align 4
  %v811 = fsub contract float 1.000000e+00, %v794
  %v812 = fmul contract float %v794, %v802
  %v813 = call float @llvm.fmuladd.f32(float %v811, float %v798, float %v812)
  %v814 = fmul contract float %v794, %v810
  %v815 = call float @llvm.fmuladd.f32(float %v811, float %v806, float %v814)
  %v816 = fmul contract float %v759, %v815
  %v817 = call float @llvm.fmuladd.f32(float %v784, float %v813, float %v816)
  %v818 = fadd contract float %v737, %v733
  %v819 = call float @llvm.maxnum.f32(float %v818, float 0.000000e+00)
  %v820 = call float @llvm.minnum.f32(float %v819, float %v745)
  %v821 = fptoui float %v820 to i32
  %v822 = add i32 %v821, 1
  %v823 = call i32 @llvm.umin.i32(i32 %v822, i32 %v741)
  %v824 = uitofp i32 %v821 to float
  %v825 = fsub contract float %v820, %v824
  %v826 = add i32 %v760, %v821
  %v827 = zext i32 %v826 to i64
  %v828 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v827
  %v829 = load float, ptr addrspace(1) %v828, align 4
  %v830 = add i32 %v760, %v823
  %v831 = zext i32 %v830 to i64
  %v832 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v831
  %v833 = load float, ptr addrspace(1) %v832, align 4
  %v834 = add i32 %v769, %v821
  %v835 = zext i32 %v834 to i64
  %v836 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v835
  %v837 = load float, ptr addrspace(1) %v836, align 4
  %v838 = add i32 %v769, %v823
  %v839 = zext i32 %v838 to i64
  %v840 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v839
  %v841 = load float, ptr addrspace(1) %v840, align 4
  %v842 = fsub contract float 1.000000e+00, %v825
  %v843 = fmul contract float %v825, %v833
  %v844 = call float @llvm.fmuladd.f32(float %v842, float %v829, float %v843)
  %v845 = fmul contract float %v825, %v841
  %v846 = call float @llvm.fmuladd.f32(float %v842, float %v837, float %v845)
  %v847 = fmul contract float %v759, %v846
  %v848 = call float @llvm.fmuladd.f32(float %v784, float %v844, float %v847)
  %v849 = fsub contract float %v739, %v735
  %v850 = call float @llvm.maxnum.f32(float %v849, float 0.000000e+00)
  %v851 = call float @llvm.minnum.f32(float %v850, float %v748)
  %v852 = fptoui float %v851 to i32
  %v853 = add i32 %v852, 1
  %v854 = call i32 @llvm.umin.i32(i32 %v853, i32 %v742)
  %v855 = uitofp i32 %v852 to float
  %v856 = fsub contract float %v851, %v855
  %v857 = mul i32 %v852, %v666
  %v858 = add i32 %v857, %v750
  %v859 = zext i32 %v858 to i64
  %v860 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v859
  %v861 = load float, ptr addrspace(1) %v860, align 4
  %v862 = add i32 %v857, %v753
  %v863 = zext i32 %v862 to i64
  %v864 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v863
  %v865 = load float, ptr addrspace(1) %v864, align 4
  %v866 = mul i32 %v854, %v666
  %v867 = add i32 %v866, %v750
  %v868 = zext i32 %v867 to i64
  %v869 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v868
  %v870 = load float, ptr addrspace(1) %v869, align 4
  %v871 = add i32 %v866, %v753
  %v872 = zext i32 %v871 to i64
  %v873 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v872
  %v874 = load float, ptr addrspace(1) %v873, align 4
  %v875 = fmul contract float %v757, %v865
  %v876 = call float @llvm.fmuladd.f32(float %v779, float %v861, float %v875)
  %v877 = fmul contract float %v757, %v874
  %v878 = call float @llvm.fmuladd.f32(float %v779, float %v870, float %v877)
  %v879 = fsub contract float 1.000000e+00, %v856
  %v880 = fmul contract float %v856, %v878
  %v881 = call float @llvm.fmuladd.f32(float %v879, float %v876, float %v880)
  %v882 = fadd contract float %v739, %v735
  %v883 = call float @llvm.maxnum.f32(float %v882, float 0.000000e+00)
  %v884 = call float @llvm.minnum.f32(float %v883, float %v748)
  %v885 = fptoui float %v884 to i32
  %v886 = add i32 %v885, 1
  %v887 = call i32 @llvm.umin.i32(i32 %v886, i32 %v742)
  %v888 = uitofp i32 %v885 to float
  %v889 = fsub contract float %v884, %v888
  %v890 = mul i32 %v885, %v666
  %v891 = add i32 %v890, %v750
  %v892 = zext i32 %v891 to i64
  %v893 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v892
  %v894 = load float, ptr addrspace(1) %v893, align 4
  %v895 = add i32 %v890, %v753
  %v896 = zext i32 %v895 to i64
  %v897 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v896
  %v898 = load float, ptr addrspace(1) %v897, align 4
  %v899 = mul i32 %v887, %v666
  %v900 = add i32 %v899, %v750
  %v901 = zext i32 %v900 to i64
  %v902 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v901
  %v903 = load float, ptr addrspace(1) %v902, align 4
  %v904 = add i32 %v899, %v753
  %v905 = zext i32 %v904 to i64
  %v906 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v905
  %v907 = load float, ptr addrspace(1) %v906, align 4
  %v908 = fmul contract float %v757, %v898
  %v909 = call float @llvm.fmuladd.f32(float %v779, float %v894, float %v908)
  %v910 = fmul contract float %v757, %v907
  %v911 = call float @llvm.fmuladd.f32(float %v779, float %v903, float %v910)
  %v912 = fsub contract float 1.000000e+00, %v889
  %v913 = fmul contract float %v889, %v911
  %v914 = call float @llvm.fmuladd.f32(float %v912, float %v909, float %v913)
  %v916 = fmul contract float %v726, f0x40490FDB
  %v917 = fdiv float %v916, %v720
  %v918 = call float @llvm.sin.f32(float %v917)
  %v919 = fmul contract float %v731, f0x40490FDB
  %v920 = fdiv float %v919, %v720
  %v921 = call float @llvm.sin.f32(float %v920)
  %v922 = fmul contract float %v918, %v918
  %v923 = fmul contract float %v922, %v921
  %v924 = fmul contract float %v923, %v921
  %v925 = fadd contract float %v817, %v848
  %v926 = fadd contract float %v925, %v881
  %v927 = fadd contract float %v926, %v914
  %v930 = call float @llvm.fmuladd.f32(float -2.500000e-01, float %v927, float %v786)
  %v931 = fmul contract float %v924, %v930
  %v932 = zext i32 %v661 to i64
  %v933 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v932
  store float %v931, ptr addrspace(1) %v933, align 4
  br label %if_merge_block8v1

else_block6v1:                                    ; preds = %if_merge_block7v1
  %v934 = zext i32 %v661 to i64
  %v935 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v934
  store float 0.000000e+00, ptr addrspace(1) %v935, align 4
  br label %if_merge_block8v1

if_merge_block8v1:                                ; preds = %else_block6v1, %then_block5v1
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 64) i32 @llvm.nvvm.read.ptx.sreg.tid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, -2147483648) i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.cos.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sin.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minnum.f32(float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #2

attributes #0 = { "nvvm.reqntid"="32,8,1" "target-cpu"="sm_86" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

; ModuleID = 'kernel'
source_filename = "kernel"
target triple = "nvptx64-nvidia-cuda"

define ptx_kernel void @fft_lines_456158b6(ptr addrspace(1) noalias readonly %0, ptr addrspace(1) noalias %1, ptr addrspace(1) noalias readonly %2, ptr addrspace(1) noalias readonly %3, ptr noalias readonly byval([80 x i8]) align 8 %4) #0 {
entry_block2v1:
  %v362 = alloca [128 x float], align 4
  %v359 = alloca [128 x float], align 4
  %v235 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v236 = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %v237 = call i32 @llvm.nvvm.read.ptx.sreg.tid.z()
  %v238 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v239 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v240 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %v241 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %v242 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.y()
  %v243 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.z()
  %v244 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %v324 = mul i32 %v236, 32
  %v325 = add i32 %v235, %v324
  %v327 = mul i32 %v237, 32
  %v329 = mul i32 %v327, 2
  %v330 = add i32 %v325, %v329
  %v331 = mul i32 %v240, %v241
  %v332 = mul i32 %v331, %v242
  %v333 = mul i32 %v239, %v241
  %v334 = add i32 %v332, %v333
  %v335 = add i32 %v334, %v238
  %v337 = mul i32 %v335, 64
  %v338 = add i32 %v337, %v330
  %v345 = getelementptr inbounds nuw i32, ptr %4, i64 6
  %v346 = load i32, ptr %v345, align 4
  %v349 = getelementptr inbounds nuw i32, ptr %4, i64 7
  %v350 = load i32, ptr %v349, align 4
  %v353 = getelementptr inbounds nuw i32, ptr %4, i64 8
  %v354 = load i32, ptr %v353, align 4
  %v355 = icmp uge i32 %v338, %v346
  br i1 %v355, label %then_block3v1, label %else_block4v1

then_block3v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block18v1

else_block4v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block18v1

if_merge_block18v1:                               ; preds = %else_block4v1, %then_block3v1
  %inv_return_flag_v497 = phi i1 [ true, %else_block4v1 ], [ false, %then_block3v1 ]
  br i1 %inv_return_flag_v497, label %then_block5v1, label %else_block6v1

then_block5v1:                                    ; preds = %if_merge_block18v1
  store [128 x float] zeroinitializer, ptr %v359, align 4
  store [128 x float] zeroinitializer, ptr %v362, align 4
  %v364 = icmp ne i32 %v350, 0
  br label %for_header_block21v1

for_header_block21v1:                             ; preds = %if_merge_block23v1, %then_block5v1
  %v297 = phi i32 [ 0, %then_block5v1 ], [ %v407, %if_merge_block23v1 ]
  %v366 = icmp ult i32 %v297, %v346
  br i1 %v366, label %body_block7v1, label %for_exit_block20v1

body_block7v1:                                    ; preds = %for_header_block21v1
  %v39 = phi i32 [ %v297, %for_header_block21v1 ]
  br label %before_block8v1

before_block8v1:                                  ; preds = %after_block9v1, %body_block7v1
  %v494 = phi i32 [ 0, %body_block7v1 ], [ %v379, %after_block9v1 ]
  %v495 = phi i32 [ %v346, %body_block7v1 ], [ %v382, %after_block9v1 ]
  %v496 = phi i32 [ %v39, %body_block7v1 ], [ %v380, %after_block9v1 ]
  %v374 = icmp ugt i32 %v495, 1
  br i1 %v374, label %after_block9v1, label %while_exit_block22v1

after_block9v1:                                   ; preds = %before_block8v1
  %v376 = shl i32 %v494, 1
  %v378 = and i32 %v496, 1
  %v379 = or i32 %v376, %v378
  %v380 = lshr i32 %v496, 1
  %v382 = lshr i32 %v495, 1
  br label %before_block8v1

while_exit_block22v1:                             ; preds = %before_block8v1
  br i1 %v364, label %then_block10v1, label %else_block11v1

then_block10v1:                                   ; preds = %while_exit_block22v1
  %v386 = mul i32 %v494, %v346
  %v387 = add i32 %v386, %v338
  %v389 = mul i32 %v387, 2
  br label %if_merge_block23v1

else_block11v1:                                   ; preds = %while_exit_block22v1
  %v390 = mul i32 %v338, %v346
  %v392 = add i32 %v390, %v494
  %v394 = mul i32 %v392, 2
  br label %if_merge_block23v1

if_merge_block23v1:                               ; preds = %else_block11v1, %then_block10v1
  %v493 = phi i32 [ %v394, %else_block11v1 ], [ %v389, %then_block10v1 ]
  %v396 = zext i32 %v493 to i64
  %v397 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v396
  %v398 = load float, ptr addrspace(1) %v397, align 4
  %v399 = zext i32 %v39 to i64
  %v400 = getelementptr inbounds nuw float, ptr %v359, i64 %v399
  store float %v398, ptr %v400, align 4
  %v401 = add i32 %v493, 1
  %v402 = zext i32 %v401 to i64
  %v403 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v402
  %v404 = load float, ptr addrspace(1) %v403, align 4
  %v405 = zext i32 %v39 to i64
  %v406 = getelementptr inbounds nuw float, ptr %v362, i64 %v405
  store float %v404, ptr %v406, align 4
  %v407 = add i32 %v39, 1
  br label %for_header_block21v1

for_exit_block20v1:                               ; preds = %for_header_block21v1
  br label %before_block12v1

before_block12v1:                                 ; preds = %for_exit_block25v1, %for_exit_block20v1
  %v492 = phi i32 [ 1, %for_exit_block20v1 ], [ %v466, %for_exit_block25v1 ]
  %v411 = icmp ult i32 %v492, %v346
  br i1 %v411, label %after_block13v1, label %while_exit_block24v1

after_block13v1:                                  ; preds = %before_block12v1
  %v414 = mul i32 2, %v492
  %v416 = call i32 @llvm.umax.i32(i32 %v414, i32 1)
  %v417 = udiv i32 %v346, %v416
  %v419 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v420 = udiv i32 %v346, %v419
  br label %for_header_block26v1

for_header_block26v1:                             ; preds = %body_block14v1, %after_block13v1
  %v300 = phi i32 [ 0, %after_block13v1 ], [ %v464, %body_block14v1 ]
  %v421 = icmp ult i32 %v300, %v420
  br i1 %v421, label %body_block14v1, label %for_exit_block25v1

body_block14v1:                                   ; preds = %for_header_block26v1
  %v110 = phi i32 [ %v300, %for_header_block26v1 ]
  %v424 = call i32 @llvm.umax.i32(i32 %v492, i32 1)
  %v425 = urem i32 %v110, %v424
  %v426 = sub i32 %v110, %v425
  %v427 = mul i32 2, %v426
  %v428 = add i32 %v427, %v425
  %v429 = add i32 %v428, %v492
  %v431 = mul i32 4, %v425
  %v432 = mul i32 %v431, %v417
  %v433 = add i32 %v432, %v354
  %v434 = zext i32 %v433 to i64
  %v435 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v434
  %v436 = load float, ptr addrspace(1) %v435, align 4
  %v437 = add i32 %v433, 1
  %v438 = zext i32 %v437 to i64
  %v439 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v438
  %v440 = load float, ptr addrspace(1) %v439, align 4
  %v441 = zext i32 %v429 to i64
  %v442 = getelementptr inbounds nuw float, ptr %v359, i64 %v441
  %v443 = load float, ptr %v442, align 4
  %v444 = zext i32 %v429 to i64
  %v445 = getelementptr inbounds nuw float, ptr %v362, i64 %v444
  %v446 = load float, ptr %v445, align 4
  %v447 = fmul contract float %v446, %v440
  %v448 = fneg float %v447
  %v449 = call float @llvm.fmuladd.f32(float %v443, float %v436, float %v448)
  %v450 = fmul contract float %v446, %v436
  %v451 = call float @llvm.fmuladd.f32(float %v443, float %v440, float %v450)
  %v452 = zext i32 %v428 to i64
  %v453 = getelementptr inbounds nuw float, ptr %v359, i64 %v452
  %v454 = load float, ptr %v453, align 4
  %v455 = fsub contract float %v454, %v449
  store float %v455, ptr %v442, align 4
  %v456 = zext i32 %v428 to i64
  %v457 = getelementptr inbounds nuw float, ptr %v362, i64 %v456
  %v458 = load float, ptr %v457, align 4
  %v459 = fsub contract float %v458, %v451
  store float %v459, ptr %v445, align 4
  %v460 = load float, ptr %v453, align 4
  %v461 = fadd contract float %v460, %v449
  store float %v461, ptr %v453, align 4
  %v462 = load float, ptr %v457, align 4
  %v463 = fadd contract float %v462, %v451
  store float %v463, ptr %v457, align 4
  %v464 = add i32 %v110, 1
  br label %for_header_block26v1

for_exit_block25v1:                               ; preds = %for_header_block26v1
  %v466 = mul i32 %v492, 2
  br label %before_block12v1

while_exit_block24v1:                             ; preds = %before_block12v1
  br label %for_header_block28v1

for_header_block28v1:                             ; preds = %if_merge_block29v1, %while_exit_block24v1
  %v303 = phi i32 [ 0, %while_exit_block24v1 ], [ %v490, %if_merge_block29v1 ]
  %v467 = icmp ult i32 %v303, %v346
  br i1 %v467, label %body_block15v1, label %for_exit_block27v1

body_block15v1:                                   ; preds = %for_header_block28v1
  %v199 = phi i32 [ %v303, %for_header_block28v1 ]
  br i1 %v364, label %then_block16v1, label %else_block17v1

then_block16v1:                                   ; preds = %body_block15v1
  %v470 = mul i32 %v199, %v346
  %v471 = add i32 %v470, %v338
  %v473 = mul i32 %v471, 2
  br label %if_merge_block29v1

else_block17v1:                                   ; preds = %body_block15v1
  %v474 = mul i32 %v338, %v346
  %v475 = add i32 %v474, %v199
  %v477 = mul i32 %v475, 2
  br label %if_merge_block29v1

if_merge_block29v1:                               ; preds = %else_block17v1, %then_block16v1
  %v491 = phi i32 [ %v477, %else_block17v1 ], [ %v473, %then_block16v1 ]
  %v478 = zext i32 %v199 to i64
  %v479 = getelementptr inbounds nuw float, ptr %v359, i64 %v478
  %v480 = load float, ptr %v479, align 4
  %v482 = zext i32 %v491 to i64
  %v483 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v482
  store float %v480, ptr addrspace(1) %v483, align 4
  %v484 = zext i32 %v199 to i64
  %v485 = getelementptr inbounds nuw float, ptr %v362, i64 %v484
  %v486 = load float, ptr %v485, align 4
  %v487 = add i32 %v491, 1
  %v488 = zext i32 %v487 to i64
  %v489 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v488
  store float %v486, ptr addrspace(1) %v489, align 4
  %v490 = add i32 %v199, 1
  br label %for_header_block28v1

for_exit_block27v1:                               ; preds = %for_header_block28v1
  br label %if_merge_block19v1

else_block6v1:                                    ; preds = %if_merge_block18v1
  br label %if_merge_block19v1

if_merge_block19v1:                               ; preds = %else_block6v1, %for_exit_block27v1
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 64) i32 @llvm.nvvm.read.ptx.sreg.tid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, -2147483648) i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #2

attributes #0 = { "nvvm.reqntid"="32,2,1" "target-cpu"="sm_86" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

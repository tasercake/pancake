#!/usr/bin/env bash
set -euo pipefail
record="$PWD/artifacts/e9-cold-kernel"
tag=${1:?Pass baseline or candidate}
if [[ $tag != baseline && $tag != baseline-cpu && $tag != candidate ]]; then exit 2; fi
cd pancake
export CARGO_TARGET_DIR="$PWD/target/e9-cold-kernel"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export CUDARC_CUDA_VERSION=12050
externs=()
for crate in cubecl_llvm cubecl_runtime; do
    lib=$(jq -er --arg crate "$crate" 'select(.reason=="compiler-artifact" and .target.name==$crate) | .filenames[] | select(endswith(".rlib"))' "$record/build-artifacts.json")
    test -f "$lib"
    sha256sum "$lib" >> "$record/$tag-compiler-externs.sha256"
    externs+=(--extern "$crate=$lib")
done
command=(taskset --cpu-list 0,1 cargo rustc --offline --locked --release -p pancake --lib --crate-type bin
    --features cubecl/cuda --message-format json -- --test "${externs[@]}")
printf '%q ' "${command[@]}" > "$record/$tag-build-probe.command"
printf '\n' >> "$record/$tag-build-probe.command"
"${command[@]}" > "$record/$tag-probe-artifacts.json" 2> "$record/$tag-build-probe.log"
bin=$(jq -er 'select(.reason=="compiler-artifact" and .target.name=="pancake") | .filenames[] | select(endswith("/pancake"))' "$record/$tag-probe-artifacts.json")
test -x "$bin"
printf '%s\n' "$bin" > "$record/$tag-probe-path.txt"
sha256sum "$bin" > "$record/$tag-probe-binary.sha256"

//! Compiler-only observations of the production registration kernels.

use std::{fs, path::PathBuf, time::Instant};

use cubecl::cuda::{CudaCompilationOptions, CudaCompiler, CudaRepresentation};
use cubecl::ir::nvidia::SmArch;
use cubecl::Compiler;
use cubecl_runtime::runtime::Runtime;
use cubecl_llvm::nvptx::ptx_version::PtxVersion;

use super::{cross_phase, fft_lines, window_luma};
use cubecl::prelude::*;

/// Expand and emit the same checked kernel representation without acquiring a device.
/// # Errors
/// Returns a missing output directory, compiler error or the failed trace write.
#[test]
fn checked_spectral_compiler_modules() -> Result<(), String> {
    let folder = PathBuf::from(std::env::var_os("PANCAKE_COLD_PROBE_OUTPUT").ok_or("output path")?);
    let side = match std::env::var("PANCAKE_COLD_PROBE_SIDE").as_deref() {
        Ok("64") => 64,
        Ok("128") => 128,
        _ => return Err("set side to 64 or 128".to_owned()),
    };
    let mut options = CudaCompilationOptions {
        arch: Some(SmArch::new(86, true)),
        ptx_version: PtxVersion::for_driver(13000),
        ..CudaCompilationOptions::default()
    };
    options.cpp.supports_features.grid_constants = true;
    fs::create_dir_all(&folder).map_err(|error| error.to_string())?;
    let mut durations = String::from("kernel\texpand_ns\temit_ns\n");
    for (label, entry, width) in [
        ("window_luma", "window_luma_7c652f0e", 8),
        ("fft_lines", "fft_lines_456158b6", side / 32),
        ("cross_phase", "cross_phase_928848a1", 8),
    ] {
        let start = Instant::now();
        let definition = build(label, entry, width)?;
        let expand = start.elapsed();
        let start = Instant::now();
        let representation = CudaCompiler::default()
            .compile(definition, &options)
            .map_err(|error| error.to_string())?;
        let emit = start.elapsed();
        let CudaRepresentation::Llvm(module) = representation else {
            return Err("The native CUDA profile must emit through LLVM".to_owned());
        };
        let ptx = module.ptx.into_iter().flat_map(i8::to_ne_bytes).collect::<Vec<u8>>();
        let text = String::from_utf8(ptx).map_err(|error| error.to_string())?;
        if !text.contains(".version 9.0") || !text.contains(".target sm_86") {
            return Err("Compiler output does not target the driver/architecture witness".to_owned());
        }
        use std::fmt::Write as _;
        writeln!(&mut durations, "{label}\t{}\t{}", expand.as_nanos(), emit.as_nanos())
            .map_err(|error| error.to_string())?;
        fs::write(folder.join(format!("{label}.ll")), module.ir).map_err(|error| error.to_string())?;
        fs::write(folder.join(format!("{label}.ptx")), text).map_err(|error| error.to_string())?;
    }
    fs::write(folder.join("durations.tsv"), durations).map_err(|error| error.to_string())
}

/// Construct tensor metadata and scalar arguments in their real launch order.
fn build(label: &str, entry: &str, planes: u32) -> Result<KernelDefinition, String> {
    let settings = KernelSettings::new(
        CubeDim::new_2d(32, planes).into(),
        ExecutionMode::Checked,
        AddressType::U32,
    )
    .kernel_name(entry);
    let mut builder = KernelBuilder::new(settings);
    builder.runtime_properties(cubecl::cuda::CudaRuntime::target_properties());
    let contiguous = TensorCompilationArg {
        meta: TensorMetaCompilationArg { len: (), rank: () },
        buffer: BufferCompilationArg { inplace: None },
    };
    let input = <Tensor<f32> as LaunchArg>::expand(&contiguous, &mut builder);
    let mut output = <Tensor<f32> as LaunchArg>::expand(&contiguous, &mut builder);
    match label {
        "window_luma" => {
            let w = <usize as LaunchArg>::expand(&(), &mut builder);
            let h = <usize as LaunchArg>::expand(&(), &mut builder);
            let side = <usize as LaunchArg>::expand(&(), &mut builder);
            window_luma::expand(&mut builder.scope, &input, &mut output, w, h, side);
        }
        "fft_lines" => {
            let side = <usize as LaunchArg>::expand(&(), &mut builder);
            let axis = <usize as LaunchArg>::expand(&(), &mut builder);
            let direction = <f32 as LaunchArg>::expand(&(), &mut builder);
            fft_lines::expand(&mut builder.scope, &input, &mut output, side, axis, direction);
        }
        "cross_phase" => {
            let mut phase = <Tensor<f32> as LaunchArg>::expand(&contiguous, &mut builder);
            let side = <usize as LaunchArg>::expand(&(), &mut builder);
            cross_phase::expand(&mut builder.scope, &input, &output, &mut phase, side);
        }
        _ => return Err("unknown kernel label".to_owned()),
    }
    Ok(builder.build())
}

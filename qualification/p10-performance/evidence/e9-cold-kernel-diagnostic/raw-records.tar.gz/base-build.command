CUDARC_CUDA_VERSION=12050 taskset --cpu-list 0,1 cargo build --offline --locked --release -p pancake --lib --features cubecl/cuda --message-format json

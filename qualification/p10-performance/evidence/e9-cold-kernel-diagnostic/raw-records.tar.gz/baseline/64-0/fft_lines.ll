; ModuleID = 'kernel'
source_filename = "kernel"
target triple = "nvptx64-nvidia-cuda"

define ptx_kernel void @fft_lines_456158b6(ptr addrspace(1) noalias readonly %0, ptr addrspace(1) noalias %1, ptr addrspace(1) noalias readonly %2, ptr noalias readonly byval([56 x i8]) align 8 %3) #0 {
entry_block2v1:
  %v344 = alloca [128 x float], align 4
  %v341 = alloca [128 x float], align 4
  %v218 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v219 = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %v220 = call i32 @llvm.nvvm.read.ptx.sreg.tid.z()
  %v221 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v222 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v223 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %v224 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %v225 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.y()
  %v226 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.z()
  %v227 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %v306 = mul i32 %v219, 32
  %v307 = add i32 %v218, %v306
  %v309 = mul i32 %v220, 32
  %v311 = mul i32 %v309, 2
  %v312 = add i32 %v307, %v311
  %v313 = mul i32 %v223, %v224
  %v314 = mul i32 %v313, %v225
  %v315 = mul i32 %v222, %v224
  %v316 = add i32 %v314, %v315
  %v317 = add i32 %v316, %v221
  %v319 = mul i32 %v317, 64
  %v320 = add i32 %v319, %v312
  %v327 = getelementptr inbounds nuw i32, ptr %3, i64 4
  %v328 = load i32, ptr %v327, align 4
  %v331 = getelementptr inbounds nuw i32, ptr %3, i64 5
  %v332 = load i32, ptr %v331, align 4
  %v335 = getelementptr inbounds nuw float, ptr %3, i64 6
  %v336 = load float, ptr %v335, align 4
  %v337 = icmp uge i32 %v320, %v328
  br i1 %v337, label %then_block3v1, label %else_block4v1

then_block3v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block18v1

else_block4v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block18v1

if_merge_block18v1:                               ; preds = %else_block4v1, %then_block3v1
  %inv_return_flag_v471 = phi i1 [ true, %else_block4v1 ], [ false, %then_block3v1 ]
  br i1 %inv_return_flag_v471, label %then_block5v1, label %else_block6v1

then_block5v1:                                    ; preds = %if_merge_block18v1
  store [128 x float] zeroinitializer, ptr %v341, align 4
  store [128 x float] zeroinitializer, ptr %v344, align 4
  %v346 = icmp ne i32 %v332, 0
  br label %for_header_block21v1

for_header_block21v1:                             ; preds = %if_merge_block23v1, %then_block5v1
  %v280 = phi i32 [ 0, %then_block5v1 ], [ %v389, %if_merge_block23v1 ]
  %v348 = icmp ult i32 %v280, %v328
  br i1 %v348, label %body_block7v1, label %for_exit_block20v1

body_block7v1:                                    ; preds = %for_header_block21v1
  %v33 = phi i32 [ %v280, %for_header_block21v1 ]
  br label %before_block8v1

before_block8v1:                                  ; preds = %after_block9v1, %body_block7v1
  %v468 = phi i32 [ 0, %body_block7v1 ], [ %v361, %after_block9v1 ]
  %v469 = phi i32 [ %v328, %body_block7v1 ], [ %v364, %after_block9v1 ]
  %v470 = phi i32 [ %v33, %body_block7v1 ], [ %v362, %after_block9v1 ]
  %v356 = icmp ugt i32 %v469, 1
  br i1 %v356, label %after_block9v1, label %while_exit_block22v1

after_block9v1:                                   ; preds = %before_block8v1
  %v358 = shl i32 %v468, 1
  %v360 = and i32 %v470, 1
  %v361 = or i32 %v358, %v360
  %v362 = lshr i32 %v470, 1
  %v364 = lshr i32 %v469, 1
  br label %before_block8v1

while_exit_block22v1:                             ; preds = %before_block8v1
  br i1 %v346, label %then_block10v1, label %else_block11v1

then_block10v1:                                   ; preds = %while_exit_block22v1
  %v368 = mul i32 %v468, %v328
  %v369 = add i32 %v368, %v320
  %v371 = mul i32 %v369, 2
  br label %if_merge_block23v1

else_block11v1:                                   ; preds = %while_exit_block22v1
  %v372 = mul i32 %v320, %v328
  %v374 = add i32 %v372, %v468
  %v376 = mul i32 %v374, 2
  br label %if_merge_block23v1

if_merge_block23v1:                               ; preds = %else_block11v1, %then_block10v1
  %v467 = phi i32 [ %v376, %else_block11v1 ], [ %v371, %then_block10v1 ]
  %v378 = zext i32 %v467 to i64
  %v379 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v378
  %v380 = load float, ptr addrspace(1) %v379, align 4
  %v381 = zext i32 %v33 to i64
  %v382 = getelementptr inbounds nuw float, ptr %v341, i64 %v381
  store float %v380, ptr %v382, align 4
  %v383 = add i32 %v467, 1
  %v384 = zext i32 %v383 to i64
  %v385 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v384
  %v386 = load float, ptr addrspace(1) %v385, align 4
  %v387 = zext i32 %v33 to i64
  %v388 = getelementptr inbounds nuw float, ptr %v344, i64 %v387
  store float %v386, ptr %v388, align 4
  %v389 = add i32 %v33, 1
  br label %for_header_block21v1

for_exit_block20v1:                               ; preds = %for_header_block21v1
  br label %before_block12v1

before_block12v1:                                 ; preds = %for_exit_block25v1, %for_exit_block20v1
  %v466 = phi i32 [ 1, %for_exit_block20v1 ], [ %v440, %for_exit_block25v1 ]
  %v393 = icmp ult i32 %v466, %v328
  br i1 %v393, label %after_block13v1, label %while_exit_block24v1

after_block13v1:                                  ; preds = %before_block12v1
  %v396 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v397 = udiv i32 %v328, %v396
  br label %for_header_block26v1

for_header_block26v1:                             ; preds = %body_block14v1, %after_block13v1
  %v283 = phi i32 [ 0, %after_block13v1 ], [ %v438, %body_block14v1 ]
  %v398 = icmp ult i32 %v283, %v397
  br i1 %v398, label %body_block14v1, label %for_exit_block25v1

body_block14v1:                                   ; preds = %for_header_block26v1
  %v100 = phi i32 [ %v283, %for_header_block26v1 ]
  %v401 = call i32 @llvm.umax.i32(i32 %v466, i32 1)
  %v402 = urem i32 %v100, %v401
  %v403 = sub i32 %v100, %v402
  %v404 = mul i32 2, %v403
  %v405 = add i32 %v404, %v402
  %v406 = add i32 %v405, %v466
  %v408 = fmul contract float %v336, f0x40490FDB
  %v409 = uitofp i32 %v402 to float
  %v410 = fmul contract float %v408, %v409
  %v411 = uitofp i32 %v466 to float
  %v412 = fdiv float %v410, %v411
  %v413 = call float @llvm.cos.f32(float %v412)
  %v414 = call float @llvm.sin.f32(float %v412)
  %v415 = zext i32 %v406 to i64
  %v416 = getelementptr inbounds nuw float, ptr %v341, i64 %v415
  %v417 = load float, ptr %v416, align 4
  %v418 = zext i32 %v406 to i64
  %v419 = getelementptr inbounds nuw float, ptr %v344, i64 %v418
  %v420 = load float, ptr %v419, align 4
  %v421 = fmul contract float %v420, %v414
  %v422 = fneg float %v421
  %v423 = call float @llvm.fmuladd.f32(float %v417, float %v413, float %v422)
  %v424 = fmul contract float %v420, %v413
  %v425 = call float @llvm.fmuladd.f32(float %v417, float %v414, float %v424)
  %v426 = zext i32 %v405 to i64
  %v427 = getelementptr inbounds nuw float, ptr %v341, i64 %v426
  %v428 = load float, ptr %v427, align 4
  %v429 = fsub contract float %v428, %v423
  store float %v429, ptr %v416, align 4
  %v430 = zext i32 %v405 to i64
  %v431 = getelementptr inbounds nuw float, ptr %v344, i64 %v430
  %v432 = load float, ptr %v431, align 4
  %v433 = fsub contract float %v432, %v425
  store float %v433, ptr %v419, align 4
  %v434 = load float, ptr %v427, align 4
  %v435 = fadd contract float %v434, %v423
  store float %v435, ptr %v427, align 4
  %v436 = load float, ptr %v431, align 4
  %v437 = fadd contract float %v436, %v425
  store float %v437, ptr %v431, align 4
  %v438 = add i32 %v100, 1
  br label %for_header_block26v1

for_exit_block25v1:                               ; preds = %for_header_block26v1
  %v440 = mul i32 %v466, 2
  br label %before_block12v1

while_exit_block24v1:                             ; preds = %before_block12v1
  br label %for_header_block28v1

for_header_block28v1:                             ; preds = %if_merge_block29v1, %while_exit_block24v1
  %v286 = phi i32 [ 0, %while_exit_block24v1 ], [ %v464, %if_merge_block29v1 ]
  %v441 = icmp ult i32 %v286, %v328
  br i1 %v441, label %body_block15v1, label %for_exit_block27v1

body_block15v1:                                   ; preds = %for_header_block28v1
  %v182 = phi i32 [ %v286, %for_header_block28v1 ]
  br i1 %v346, label %then_block16v1, label %else_block17v1

then_block16v1:                                   ; preds = %body_block15v1
  %v444 = mul i32 %v182, %v328
  %v445 = add i32 %v444, %v320
  %v447 = mul i32 %v445, 2
  br label %if_merge_block29v1

else_block17v1:                                   ; preds = %body_block15v1
  %v448 = mul i32 %v320, %v328
  %v449 = add i32 %v448, %v182
  %v451 = mul i32 %v449, 2
  br label %if_merge_block29v1

if_merge_block29v1:                               ; preds = %else_block17v1, %then_block16v1
  %v465 = phi i32 [ %v451, %else_block17v1 ], [ %v447, %then_block16v1 ]
  %v452 = zext i32 %v182 to i64
  %v453 = getelementptr inbounds nuw float, ptr %v341, i64 %v452
  %v454 = load float, ptr %v453, align 4
  %v456 = zext i32 %v465 to i64
  %v457 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v456
  store float %v454, ptr addrspace(1) %v457, align 4
  %v458 = zext i32 %v182 to i64
  %v459 = getelementptr inbounds nuw float, ptr %v344, i64 %v458
  %v460 = load float, ptr %v459, align 4
  %v461 = add i32 %v465, 1
  %v462 = zext i32 %v461 to i64
  %v463 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v462
  store float %v460, ptr addrspace(1) %v463, align 4
  %v464 = add i32 %v182, 1
  br label %for_header_block28v1

for_exit_block27v1:                               ; preds = %for_header_block28v1
  br label %if_merge_block19v1

else_block6v1:                                    ; preds = %if_merge_block18v1
  br label %if_merge_block19v1

if_merge_block19v1:                               ; preds = %else_block6v1, %for_exit_block27v1
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 64) i32 @llvm.nvvm.read.ptx.sreg.tid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, -2147483648) i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.cos.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sin.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #2

attributes #0 = { "nvvm.reqntid"="32,2,1" "target-cpu"="sm_86" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

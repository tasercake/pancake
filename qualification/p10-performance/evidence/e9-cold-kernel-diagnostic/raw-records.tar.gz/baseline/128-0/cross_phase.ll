; ModuleID = 'kernel'
source_filename = "kernel"
target triple = "nvptx64-nvidia-cuda"

define ptx_kernel void @cross_phase_928848a1(ptr addrspace(1) noalias readonly %0, ptr addrspace(1) noalias readonly %1, ptr addrspace(1) noalias %2, ptr addrspace(1) noalias readonly %3, ptr noalias readonly byval([72 x i8]) align 8 %4) #0 {
entry_block2v1:
  %v107 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v108 = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %v109 = call i32 @llvm.nvvm.read.ptx.sreg.tid.z()
  %v110 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v111 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v112 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %v113 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %v114 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.y()
  %v115 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.z()
  %v116 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %v177 = mul i32 %v108, 32
  %v178 = add i32 %v107, %v177
  %v180 = mul i32 %v109, 32
  %v182 = mul i32 %v180, 8
  %v183 = add i32 %v178, %v182
  %v184 = mul i32 %v112, %v113
  %v185 = mul i32 %v184, %v114
  %v186 = mul i32 %v111, %v113
  %v187 = add i32 %v185, %v186
  %v188 = add i32 %v187, %v110
  %v190 = mul i32 %v188, 256
  %v191 = add i32 %v190, %v183
  %v195 = getelementptr inbounds nuw i32, ptr %4, i64 6
  %v196 = load i32, ptr %v195, align 4
  %v199 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v200 = udiv i32 %v191, %v199
  %v201 = mul i32 %v196, %v196
  %v203 = call i32 @llvm.umax.i32(i32 %v201, i32 1)
  %v204 = urem i32 %v200, %v203
  %v205 = mul i32 %v204, 2
  %v206 = zext i32 %v205 to i64
  %v207 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v206
  %v208 = load float, ptr addrspace(1) %v207, align 4
  %v209 = zext i32 %v205 to i64
  %v210 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v209
  %v211 = load float, ptr addrspace(1) %v210, align 4
  %v213 = add i32 %v205, 1
  %v214 = zext i32 %v213 to i64
  %v215 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v214
  %v216 = load float, ptr addrspace(1) %v215, align 4
  %v217 = zext i32 %v213 to i64
  %v218 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v217
  %v219 = load float, ptr addrspace(1) %v218, align 4
  %v220 = fmul contract float %v216, %v219
  %v221 = call float @llvm.fmuladd.f32(float %v208, float %v211, float %v220)
  %v222 = fmul contract float %v208, %v219
  %v223 = fneg float %v222
  %v224 = call float @llvm.fmuladd.f32(float %v216, float %v211, float %v223)
  %v225 = fmul contract float %v224, %v224
  %v226 = call float @llvm.fmuladd.f32(float %v221, float %v221, float %v225)
  %v227 = call float @llvm.sqrt.f32(float %v226)
  %v229 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v230 = urem i32 %v191, %v229
  %v231 = icmp eq i32 %v230, 0
  br i1 %v231, label %then_block3v1, label %else_block4v1

then_block3v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block7v1

else_block4v1:                                    ; preds = %entry_block2v1
  br label %if_merge_block7v1

if_merge_block7v1:                                ; preds = %else_block4v1, %then_block3v1
  %v245 = phi float [ %v224, %else_block4v1 ], [ %v221, %then_block3v1 ]
  %v235 = fcmp ogt float %v227, f0x3089705F
  br i1 %v235, label %then_block5v1, label %else_block6v1

then_block5v1:                                    ; preds = %if_merge_block7v1
  %v239 = fdiv float %v245, %v227
  br label %if_merge_block8v1

else_block6v1:                                    ; preds = %if_merge_block7v1
  br label %if_merge_block8v1

if_merge_block8v1:                                ; preds = %else_block6v1, %then_block5v1
  %v244 = phi float [ 0.000000e+00, %else_block6v1 ], [ %v239, %then_block5v1 ]
  %v241 = zext i32 %v191 to i64
  %v242 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v241
  store float %v244, ptr addrspace(1) %v242, align 4
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 64) i32 @llvm.nvvm.read.ptx.sreg.tid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, -2147483648) i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #2

attributes #0 = { "nvvm.reqntid"="32,8,1" "target-cpu"="sm_86" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

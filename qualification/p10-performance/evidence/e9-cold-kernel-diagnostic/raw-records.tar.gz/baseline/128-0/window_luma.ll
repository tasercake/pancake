; ModuleID = 'kernel'
source_filename = "kernel"
target triple = "nvptx64-nvidia-cuda"

define ptx_kernel void @window_luma_7c652f0e(ptr addrspace(1) noalias readonly %0, ptr addrspace(1) noalias %1, ptr addrspace(1) noalias readonly %2, ptr noalias readonly byval([56 x i8]) align 8 %3) #0 {
entry_block2v1:
  %v512 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v513 = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %v514 = call i32 @llvm.nvvm.read.ptx.sreg.tid.z()
  %v515 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v516 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v517 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %v518 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %v519 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.y()
  %v520 = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.z()
  %v521 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %v592 = mul i32 %v513, 32
  %v593 = add i32 %v512, %v592
  %v595 = mul i32 %v514, 32
  %v597 = mul i32 %v595, 8
  %v598 = add i32 %v593, %v597
  %v599 = mul i32 %v517, %v518
  %v600 = mul i32 %v599, %v519
  %v601 = mul i32 %v516, %v518
  %v602 = add i32 %v600, %v601
  %v603 = add i32 %v602, %v515
  %v605 = mul i32 %v603, 256
  %v606 = add i32 %v605, %v598
  %v610 = getelementptr inbounds nuw i32, ptr %3, i64 4
  %v611 = load i32, ptr %v610, align 4
  %v614 = getelementptr inbounds nuw i32, ptr %3, i64 5
  %v615 = load i32, ptr %v614, align 4
  %v618 = getelementptr inbounds nuw i32, ptr %3, i64 6
  %v619 = load i32, ptr %v618, align 4
  %v622 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v623 = udiv i32 %v606, %v622
  %v625 = call i32 @llvm.umax.i32(i32 2, i32 1)
  %v626 = urem i32 %v606, %v625
  %v627 = icmp eq i32 %v626, 0
  br i1 %v627, label %then_block3v1, label %else_block4v1

then_block3v1:                                    ; preds = %entry_block2v1
  %v628 = uitofp i32 %v619 to float
  %v630 = call i32 @llvm.umax.i32(i32 %v619, i32 1)
  %v631 = urem i32 %v623, %v630
  %v632 = uitofp i32 %v631 to float
  %v634 = fadd contract float %v632, 5.000000e-01
  %v636 = call i32 @llvm.umax.i32(i32 %v619, i32 1)
  %v637 = udiv i32 %v623, %v636
  %v638 = uitofp i32 %v637 to float
  %v639 = fadd contract float %v638, 5.000000e-01
  %v640 = uitofp i32 %v611 to float
  %v641 = fdiv float %v640, %v628
  %v642 = uitofp i32 %v615 to float
  %v643 = fdiv float %v642, %v628
  %v645 = call float @llvm.fmuladd.f32(float %v634, float %v641, float -5.000000e-01)
  %v647 = call float @llvm.fmuladd.f32(float %v639, float %v643, float -5.000000e-01)
  %v649 = sub i32 %v611, 1
  %v650 = sub i32 %v615, 1
  %v652 = call float @llvm.maxnum.f32(float %v645, float 0.000000e+00)
  %v653 = uitofp i32 %v649 to float
  %v654 = call float @llvm.minnum.f32(float %v652, float %v653)
  %v655 = call float @llvm.maxnum.f32(float %v647, float 0.000000e+00)
  %v656 = uitofp i32 %v650 to float
  %v657 = call float @llvm.minnum.f32(float %v655, float %v656)
  %v658 = fptoui float %v654 to i32
  %v659 = fptoui float %v657 to i32
  %v660 = add i32 %v658, 1
  %v661 = call i32 @llvm.umin.i32(i32 %v660, i32 %v649)
  %v662 = add i32 %v659, 1
  %v663 = call i32 @llvm.umin.i32(i32 %v662, i32 %v650)
  %v664 = uitofp i32 %v658 to float
  %v665 = fsub contract float %v654, %v664
  %v666 = uitofp i32 %v659 to float
  %v667 = fsub contract float %v657, %v666
  %v668 = mul i32 %v659, %v611
  %v669 = add i32 %v668, %v658
  %v670 = zext i32 %v669 to i64
  %v671 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v670
  %v672 = load float, ptr addrspace(1) %v671, align 4
  %v673 = add i32 %v668, %v661
  %v674 = zext i32 %v673 to i64
  %v675 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v674
  %v676 = load float, ptr addrspace(1) %v675, align 4
  %v677 = mul i32 %v663, %v611
  %v678 = add i32 %v677, %v658
  %v679 = zext i32 %v678 to i64
  %v680 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v679
  %v681 = load float, ptr addrspace(1) %v680, align 4
  %v682 = add i32 %v677, %v661
  %v683 = zext i32 %v682 to i64
  %v684 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v683
  %v685 = load float, ptr addrspace(1) %v684, align 4
  %v687 = fsub contract float 1.000000e+00, %v665
  %v688 = fmul contract float %v665, %v676
  %v689 = call float @llvm.fmuladd.f32(float %v687, float %v672, float %v688)
  %v690 = fmul contract float %v665, %v685
  %v691 = call float @llvm.fmuladd.f32(float %v687, float %v681, float %v690)
  %v692 = fsub contract float 1.000000e+00, %v667
  %v693 = fmul contract float %v667, %v691
  %v694 = call float @llvm.fmuladd.f32(float %v692, float %v689, float %v693)
  %v695 = fsub contract float %v645, %v641
  %v696 = call float @llvm.maxnum.f32(float %v695, float 0.000000e+00)
  %v697 = call float @llvm.minnum.f32(float %v696, float %v653)
  %v698 = fptoui float %v697 to i32
  %v699 = add i32 %v698, 1
  %v700 = call i32 @llvm.umin.i32(i32 %v699, i32 %v649)
  %v701 = uitofp i32 %v698 to float
  %v702 = fsub contract float %v697, %v701
  %v703 = add i32 %v668, %v698
  %v704 = zext i32 %v703 to i64
  %v705 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v704
  %v706 = load float, ptr addrspace(1) %v705, align 4
  %v707 = add i32 %v668, %v700
  %v708 = zext i32 %v707 to i64
  %v709 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v708
  %v710 = load float, ptr addrspace(1) %v709, align 4
  %v711 = add i32 %v677, %v698
  %v712 = zext i32 %v711 to i64
  %v713 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v712
  %v714 = load float, ptr addrspace(1) %v713, align 4
  %v715 = add i32 %v677, %v700
  %v716 = zext i32 %v715 to i64
  %v717 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v716
  %v718 = load float, ptr addrspace(1) %v717, align 4
  %v719 = fsub contract float 1.000000e+00, %v702
  %v720 = fmul contract float %v702, %v710
  %v721 = call float @llvm.fmuladd.f32(float %v719, float %v706, float %v720)
  %v722 = fmul contract float %v702, %v718
  %v723 = call float @llvm.fmuladd.f32(float %v719, float %v714, float %v722)
  %v724 = fmul contract float %v667, %v723
  %v725 = call float @llvm.fmuladd.f32(float %v692, float %v721, float %v724)
  %v726 = fadd contract float %v645, %v641
  %v727 = call float @llvm.maxnum.f32(float %v726, float 0.000000e+00)
  %v728 = call float @llvm.minnum.f32(float %v727, float %v653)
  %v729 = fptoui float %v728 to i32
  %v730 = add i32 %v729, 1
  %v731 = call i32 @llvm.umin.i32(i32 %v730, i32 %v649)
  %v732 = uitofp i32 %v729 to float
  %v733 = fsub contract float %v728, %v732
  %v734 = add i32 %v668, %v729
  %v735 = zext i32 %v734 to i64
  %v736 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v735
  %v737 = load float, ptr addrspace(1) %v736, align 4
  %v738 = add i32 %v668, %v731
  %v739 = zext i32 %v738 to i64
  %v740 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v739
  %v741 = load float, ptr addrspace(1) %v740, align 4
  %v742 = add i32 %v677, %v729
  %v743 = zext i32 %v742 to i64
  %v744 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v743
  %v745 = load float, ptr addrspace(1) %v744, align 4
  %v746 = add i32 %v677, %v731
  %v747 = zext i32 %v746 to i64
  %v748 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v747
  %v749 = load float, ptr addrspace(1) %v748, align 4
  %v750 = fsub contract float 1.000000e+00, %v733
  %v751 = fmul contract float %v733, %v741
  %v752 = call float @llvm.fmuladd.f32(float %v750, float %v737, float %v751)
  %v753 = fmul contract float %v733, %v749
  %v754 = call float @llvm.fmuladd.f32(float %v750, float %v745, float %v753)
  %v755 = fmul contract float %v667, %v754
  %v756 = call float @llvm.fmuladd.f32(float %v692, float %v752, float %v755)
  %v757 = fsub contract float %v647, %v643
  %v758 = call float @llvm.maxnum.f32(float %v757, float 0.000000e+00)
  %v759 = call float @llvm.minnum.f32(float %v758, float %v656)
  %v760 = fptoui float %v759 to i32
  %v761 = add i32 %v760, 1
  %v762 = call i32 @llvm.umin.i32(i32 %v761, i32 %v650)
  %v763 = uitofp i32 %v760 to float
  %v764 = fsub contract float %v759, %v763
  %v765 = mul i32 %v760, %v611
  %v766 = add i32 %v765, %v658
  %v767 = zext i32 %v766 to i64
  %v768 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v767
  %v769 = load float, ptr addrspace(1) %v768, align 4
  %v770 = add i32 %v765, %v661
  %v771 = zext i32 %v770 to i64
  %v772 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v771
  %v773 = load float, ptr addrspace(1) %v772, align 4
  %v774 = mul i32 %v762, %v611
  %v775 = add i32 %v774, %v658
  %v776 = zext i32 %v775 to i64
  %v777 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v776
  %v778 = load float, ptr addrspace(1) %v777, align 4
  %v779 = add i32 %v774, %v661
  %v780 = zext i32 %v779 to i64
  %v781 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v780
  %v782 = load float, ptr addrspace(1) %v781, align 4
  %v783 = fmul contract float %v665, %v773
  %v784 = call float @llvm.fmuladd.f32(float %v687, float %v769, float %v783)
  %v785 = fmul contract float %v665, %v782
  %v786 = call float @llvm.fmuladd.f32(float %v687, float %v778, float %v785)
  %v787 = fsub contract float 1.000000e+00, %v764
  %v788 = fmul contract float %v764, %v786
  %v789 = call float @llvm.fmuladd.f32(float %v787, float %v784, float %v788)
  %v790 = fadd contract float %v647, %v643
  %v791 = call float @llvm.maxnum.f32(float %v790, float 0.000000e+00)
  %v792 = call float @llvm.minnum.f32(float %v791, float %v656)
  %v793 = fptoui float %v792 to i32
  %v794 = add i32 %v793, 1
  %v795 = call i32 @llvm.umin.i32(i32 %v794, i32 %v650)
  %v796 = uitofp i32 %v793 to float
  %v797 = fsub contract float %v792, %v796
  %v798 = mul i32 %v793, %v611
  %v799 = add i32 %v798, %v658
  %v800 = zext i32 %v799 to i64
  %v801 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v800
  %v802 = load float, ptr addrspace(1) %v801, align 4
  %v803 = add i32 %v798, %v661
  %v804 = zext i32 %v803 to i64
  %v805 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v804
  %v806 = load float, ptr addrspace(1) %v805, align 4
  %v807 = mul i32 %v795, %v611
  %v808 = add i32 %v807, %v658
  %v809 = zext i32 %v808 to i64
  %v810 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v809
  %v811 = load float, ptr addrspace(1) %v810, align 4
  %v812 = add i32 %v807, %v661
  %v813 = zext i32 %v812 to i64
  %v814 = getelementptr inbounds nuw float, ptr addrspace(1) %0, i64 %v813
  %v815 = load float, ptr addrspace(1) %v814, align 4
  %v816 = fmul contract float %v665, %v806
  %v817 = call float @llvm.fmuladd.f32(float %v687, float %v802, float %v816)
  %v818 = fmul contract float %v665, %v815
  %v819 = call float @llvm.fmuladd.f32(float %v687, float %v811, float %v818)
  %v820 = fsub contract float 1.000000e+00, %v797
  %v821 = fmul contract float %v797, %v819
  %v822 = call float @llvm.fmuladd.f32(float %v820, float %v817, float %v821)
  %v824 = fmul contract float %v634, f0x40490FDB
  %v825 = fdiv float %v824, %v628
  %v826 = call float @llvm.sin.f32(float %v825)
  %v827 = fmul contract float %v639, f0x40490FDB
  %v828 = fdiv float %v827, %v628
  %v829 = call float @llvm.sin.f32(float %v828)
  %v830 = fmul contract float %v826, %v826
  %v831 = fmul contract float %v830, %v829
  %v832 = fmul contract float %v831, %v829
  %v833 = fadd contract float %v725, %v756
  %v834 = fadd contract float %v833, %v789
  %v835 = fadd contract float %v834, %v822
  %v838 = call float @llvm.fmuladd.f32(float -2.500000e-01, float %v835, float %v694)
  %v839 = fmul contract float %v832, %v838
  %v840 = zext i32 %v606 to i64
  %v841 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v840
  store float %v839, ptr addrspace(1) %v841, align 4
  br label %if_merge_block5v1

else_block4v1:                                    ; preds = %entry_block2v1
  %v842 = zext i32 %v606 to i64
  %v843 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v842
  store float 0.000000e+00, ptr addrspace(1) %v843, align 4
  br label %if_merge_block5v1

if_merge_block5v1:                                ; preds = %else_block4v1, %then_block3v1
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 64) i32 @llvm.nvvm.read.ptx.sreg.tid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, -2147483648) i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 1, 65536) i32 @llvm.nvvm.read.ptx.sreg.nctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minnum.f32(float, float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sin.f32(float) #2

attributes #0 = { "nvvm.reqntid"="32,8,1" "target-cpu"="sm_86" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

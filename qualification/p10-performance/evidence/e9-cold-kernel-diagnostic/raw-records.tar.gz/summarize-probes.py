"""Summarize raw host-only compilation for matching kernel modules."""
import csv
import json
from pathlib import Path
from statistics import median
import sys

root = Path(sys.argv[1])
variants = [path for path in ("baseline", "candidate") if (root / path).is_dir()]
summary = {}
for variant in variants:
    by_side = {}
    for side in (64, 128):
        repeat = []
        for sample in range(5):
            directory = root / variant / f"{side}-{sample}"
            with (directory / "durations.tsv").open(newline="") as stream:
                rows = list(csv.DictReader(stream, delimiter="\t"))
            assert [row["kernel"] for row in rows] == ["window_luma", "fft_lines", "cross_phase"]
            repeat.append({
                row["kernel"]: {name: int(row[name]) for name in ("expand_ns", "emit_ns")}
                for row in rows
            })
            for name in ("window_luma", "fft_lines", "cross_phase"):
                ptx = (directory / f"{name}.ptx").read_bytes()
                assert b".version 9.0" in ptx and b".target sm_86" in ptx
                assert len(ptx) > 100
        keys = repeat[0].keys()
        by_side[str(side)] = {
            "samples": repeat,
            "median_by_module_ns": {
                name: {
                    field: median(run[name][field] for run in repeat)
                    for field in ("expand_ns", "emit_ns")
                }
                for name in keys
            },
            "median_spectral_set_ns": median(
                sum(time for stages in run.values() for time in stages.values()) for run in repeat
            ),
            "median_changed_set_ns": median(
                sum(time for name in ("window_luma", "fft_lines") for time in run[name].values())
                for run in repeat
            ),
        }
    summary[variant] = by_side
(root / "compiler-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
for variant, by_side in summary.items():
    for side, values in by_side.items():
        timings = values["median_by_module_ns"]
        print(variant, side, *(f"{kernel}={sum(parts.values())/1e6:.3f}ms" for kernel, parts in timings.items()),
              f"total={values['median_spectral_set_ns']/1e6:.3f}ms")

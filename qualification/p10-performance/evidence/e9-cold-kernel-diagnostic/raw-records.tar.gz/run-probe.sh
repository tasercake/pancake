#!/usr/bin/env bash
set -euo pipefail
record="$PWD/artifacts/e9-cold-kernel"
tag=${1:?Pass baseline or candidate}
if [[ $tag != baseline && $tag != candidate ]]; then exit 2; fi
bin=$(cat "$record/$tag-probe-path.txt")
sha256sum --check "$record/$tag-probe-binary.sha256"
for side in 64 128; do
    for repeat in 0 1 2 3 4; do
        output="$record/$tag/$side-$repeat"
        mkdir -p "$output"
        CUDA_PATH=/usr/local/cuda-12.5 PANCAKE_COLD_PROBE_SIDE="$side" PANCAKE_COLD_PROBE_OUTPUT="$output" \
            taskset --cpu-list 0 "$bin" registration::spectral::cold_probe::checked_spectral_compiler_modules \
            --exact > "$output/probe.log" 2>&1
        rg -q '^test result: ok\. 1 passed;' "$output/probe.log"
    done
done

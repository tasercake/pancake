#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/weighted-resident"
build="$base/cuda-probe"
record="$base/cuda-run"
test -s "$base/cuda-lease.txt"
grep -qx 0 "$build/exit.txt"
git diff --exit-code a49ce692371558ff40f72b0af77f5249d00dcedb HEAD -- pancake
test -z "$(git status --porcelain=v1)"
sha256sum -c "$build/retained-binary.sha256"
read -r digest binary < "$build/retained-binary.sha256"
mkdir -m 700 "$record"
trap 'status=$?; { date -u +%FT%TZ; printf "exit=%s\n" "$status"; } > "$record/terminal.txt"' EXIT
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS PANCAKE_RUNTIME CUDA_VISIBLE_DEVICES
unset VK_ICD_FILENAMES VK_ADD_DRIVER_FILES LD_LIBRARY_PATH CUDA_PATH
export CUDA_PATH=/usr/local/cuda-12.5
export LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64
export XDG_RUNTIME_DIR="$record/runtime"
export HOME="$record/home" XDG_CACHE_HOME="$record/cache" TMPDIR="$record/tmp"
mkdir -m 700 "$XDG_RUNTIME_DIR" "$HOME" "$XDG_CACHE_HOME" "$TMPDIR"
export PANCAKE_WEIGHTED_PROBE_OUTPUT="$record/output"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$record/nvidia.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/nvidia.txt"
cd "$record"
printf '%s\n' "HOME=$HOME" "XDG_CACHE_HOME=$XDG_CACHE_HOME" "TMPDIR=$TMPDIR" "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR" "CUDA_PATH=$CUDA_PATH" "LD_LIBRARY_PATH=$LD_LIBRARY_PATH" "PANCAKE_WEIGHTED_PROBE_OUTPUT=$PANCAKE_WEIGHTED_PROBE_OUTPUT" > run-settings.txt
common=(timeout --signal=TERM --kill-after=5s 45s taskset -c 10,11 "$binary")
cmd=("${common[@]}" job::weighted_probe:: --test-threads=1)
printf '%q ' "${cmd[@]}" > stack.command
printf '\n' >> stack.command
"${cmd[@]}" > stack.log 2>&1
cmd=("${common[@]}" --exact fusion::focus::weighted_input_probe::cuda_weighted_first_import_is_atomic --test-threads=1)
printf '%q ' "${cmd[@]}" > input.command
printf '\n' >> input.command
"${cmd[@]}" > input.log 2>&1

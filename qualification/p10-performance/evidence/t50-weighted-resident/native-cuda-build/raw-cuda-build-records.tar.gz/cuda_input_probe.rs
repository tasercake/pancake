//! Temporary native check for resident focus weight bits and failed first import.

use crate::config::DevicePreference;
use crate::image_io::RgbImage;
use crate::registration::{Frame, ResidentRgb, frame_thumbnail};
use crate::runtime::{RuntimeOverride, select_runtime};

use super::{FocusAccumulator, FocusMethod, read_image};

/// Create an actual checked registration upload from a validated fixture.
fn resident(device: &cubecl::Device, image: &RgbImage) -> Result<ResidentRgb, String> {
    let frame = Frame::new(image.width(), image.height(), image.samples())?;
    let (_, resident) = frame_thumbnail(
        device,
        frame,
        [image.width(), image.height()],
        1,
        16 * 1024 * 1024,
        true,
    )?;
    resident.ok_or("registration did not keep its actual luma input".to_owned())
}

/// Generate finite nonuniform values and a truly flat zero-weight control.
fn scene(width: usize, height: usize, index: usize) -> Result<RgbImage, String> {
    let samples = width.saturating_mul(height).saturating_mul(3);
    let values = if index == 0 {
        vec![0.25; samples]
    } else {
        (0..253_u8)
            .cycle()
            .skip(index)
            .take(samples)
            .map(|value| f32::from(value) / 256.0)
            .collect()
    };
    RgbImage::new(width, height, values)
}

/// Read existing weight/result planes after the original successful frame wait.
fn planes(accumulator: &FocusAccumulator) -> Result<(Vec<u32>, Vec<u32>), String> {
    let state = accumulator
        .state
        .as_ref()
        .map_err(String::clone)?
        .as_ref()
        .ok_or("valid input left no focus state")?;
    let read = |tensor| {
        read_image(&state.client, tensor, accumulator.shape.area)
            .map(|values| values.into_iter().map(f32::to_bits).collect())
    };
    Ok((read(state.weights.clone())?, read(state.scores.clone())?))
}

/// Wrong packed geometry must leave lazy first-state uninitialized.
#[test]
fn cuda_weighted_first_import_is_atomic() -> Result<(), String> {
    let runtime = select_runtime(
        DevicePreference::Gpu,
        Some(0),
        16 * 1024 * 1024,
        Some(RuntimeOverride::Cuda),
    )?;
    if runtime.runtime_name() != "cuda"
        || !runtime.physical_gpu()
        || runtime.fallback_reason().is_some()
        || runtime.device_pci_address() != Some("0000:01:00.0")
        || runtime.device_name() != "NVIDIA GeForce RTX 3090"
        || runtime.fingerprint() != "ptx_sm86"
    {
        return Err("the requested physical CUDA runtime did not qualify".into());
    }
    let device = runtime.device();
    let create = || {
        FocusAccumulator::new(
            device,
            19,
            13,
            FocusMethod::WeightedAverage,
            6,
            16 * 1024 * 1024,
        )
    };
    let mut imported = create()?;
    let mut host = create()?;
    let wrong = resident(device, &scene(17, 11, 1)?)?;
    if !matches!(imported.add_normalized_frame(&[], Some(wrong)),
            Err(error) if error.contains("resident RGB does not match"))
        || !matches!(imported.state, Ok(None))
    {
        return Err("a rejected first resident initialized or poisoned the focus state".to_owned());
    }

    let cpu = cubecl::Device::cpu().map_err(|error| error.to_string())?;
    let foreign = resident(&cpu, &scene(19, 13, 1)?)?;
    if !matches!(imported.add_normalized_frame(&[], Some(foreign)),
            Err(error) if error.contains("different compute service"))
        || !matches!(imported.state, Ok(None))
    {
        return Err(
            "a rejected foreign resident initialized or poisoned the focus state".to_owned(),
        );
    }

    for index in [0, 1, 3, 9] {
        let image = scene(19, 13, index)?;
        host.add_frame(image.samples())?;
        let input = resident(device, &image)?;
        drop(image);
        imported.add_normalized_frame(&[], Some(input))?;
        let original = planes(&host)?;
        let actual = planes(&imported)?;
        if original != actual {
            return Err(format!("weight or score bits changed at fixture {index}"));
        }
        if index == 0 && actual.0.iter().any(|&bits| bits != 0.0_f32.to_bits()) {
            return Err("flat first-frame weights were nonzero".to_owned());
        }
    }
    if !host
        .finish()?
        .into_iter()
        .map(f32::to_bits)
        .eq(imported.finish()?.into_iter().map(f32::to_bits))
    {
        return Err("valid frames after a rejected resident changed final RGB bits".to_owned());
    }
    Ok(())
}

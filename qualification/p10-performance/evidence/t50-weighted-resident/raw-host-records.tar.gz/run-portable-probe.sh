#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/weighted-resident"
build="$base/portable-probe"
record="$base/portable-run"
test -s "$base/portable-lease.txt"
grep -qx 0 "$build/exit.txt"
git diff --exit-code a49ce692371558ff40f72b0af77f5249d00dcedb HEAD -- pancake
test -z "$(git status --porcelain=v1)"
sha256sum -c "$build/retained-binary.sha256"
read -r digest binary < "$build/retained-binary.sha256"
mkdir -m 700 "$record"
trap 'status=$?; { date -u +%FT%TZ; printf "exit=%s\n" "$status"; } > "$record/terminal.txt"' EXIT
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS PANCAKE_RUNTIME CUDA_VISIBLE_DEVICES
unset VK_ICD_FILENAMES VK_ADD_DRIVER_FILES LD_LIBRARY_PATH CUDA_PATH
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
export XDG_RUNTIME_DIR="$record/runtime"
export HOME="$record/home" XDG_CACHE_HOME="$record/cache" TMPDIR="$record/tmp"
mkdir -m 700 "$XDG_RUNTIME_DIR" "$HOME" "$XDG_CACHE_HOME" "$TMPDIR"
export PANCAKE_WEIGHTED_PROBE_OUTPUT="$record/output"
sha256sum "$VK_DRIVER_FILES" > "$record/icd.sha256"
nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$record/nvidia.txt"
vulkaninfo --summary > "$record/vulkaninfo.txt" 2> "$record/vulkaninfo-stderr.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/nvidia.txt"
grep -qF 'NVIDIA GeForce RTX 3090' "$record/vulkaninfo.txt"
test "$(grep -c '^GPU[0-9]' "$record/vulkaninfo.txt")" = 1
cd "$record"
printf '%s\n' "HOME=$HOME" "XDG_CACHE_HOME=$XDG_CACHE_HOME" "TMPDIR=$TMPDIR" "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR" "VK_DRIVER_FILES=$VK_DRIVER_FILES" "PANCAKE_WEIGHTED_PROBE_OUTPUT=$PANCAKE_WEIGHTED_PROBE_OUTPUT" > run-settings.txt
common=(timeout --signal=TERM --kill-after=5s 45s taskset -c 10,11 "$binary")
cmd=("${common[@]}" job::weighted_probe:: --test-threads=1)
printf '%q ' "${cmd[@]}" > stack.command
printf '\n' >> stack.command
"${cmd[@]}" > stack.log 2>&1
cmd=("${common[@]}" --exact fusion::focus::weighted_input_probe::vulkan_weighted_first_import_is_atomic --test-threads=1)
printf '%q ' "${cmd[@]}" > input.command
printf '\n' >> input.command
"${cmd[@]}" > input.log 2>&1

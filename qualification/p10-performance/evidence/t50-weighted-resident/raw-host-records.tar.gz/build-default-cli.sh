#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/weighted-resident"
record="$base/default-release"
test "$(git rev-parse HEAD)" = a49ce692371558ff40f72b0af77f5249d00dcedb
test -z "$(git status --porcelain=v1)"
mkdir -p "$record"
cd "$root/pancake"
unset CUDARC_CUDA_VERSION RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/target/weighted-resident-cpu"
git rev-parse HEAD 'HEAD^{tree}' 'HEAD:pancake' > "$record/source-tree.txt"
sha256sum Cargo.lock Cargo.toml crates/pancake-cli/Cargo.toml > "$record/source-pin.sha256"
rustc +1.100.0 -Vv > "$record/rustc.txt"
cargo +1.100.0 -Vv > "$record/cargo.txt"
printf 'jobs=2\nincremental=0\nnet_offline=true\nwrapper=unset\ntarget=%s\n' "$CARGO_TARGET_DIR" > "$record/build-settings.txt"
cmd=(taskset -c 10,11 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli)
printf '%q ' "${cmd[@]}" > "$record/build.command"
printf '\n' >> "$record/build.command"
trap 'status=$?; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
date -u +%FT%TZ > "$record/start.txt"
/usr/bin/time -v -o "$record/build-resources.txt" "${cmd[@]}" > "$record/build.log" 2>&1
binary="$CARGO_TARGET_DIR/release/pancake-cli"
sha256sum "$binary" > "$record/binary.sha256"
readelf -W -h -n -d "$binary" > "$record/elf-static.txt"
taskset -c 10,11 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli -e normal,build > "$record/default-graph.txt"
grep -qF cubecl-cpu "$record/default-graph.txt"
grep -qF cubecl-wgpu "$record/default-graph.txt"
if grep -Eq '^.*(slint v|cubecl-cuda v|cubecl-hip v|cudarc v)' "$record/default-graph.txt"; then
    printf '%s\n' 'unexpected frontend or optional native backend'
    exit 1
fi
nm --defined-only --demangle "$binary" | awk '
    /cubecl_cpu::/ { cpu++ } /cubecl_wgpu::/ { wgpu++ }
    /wgpu_hal::vulkan/ { vk++ } /cubecl_cuda::|cubecl_hip::/ { native++ }
    END { print "CPU", cpu, "wgpu", wgpu, "Vulkan HAL", vk, "optional native", (native+0);
          exit !(cpu>0 && wgpu>0 && vk>0 && native==0); }
' > "$record/linked-symbol-counts.txt"
sha256sum -c "$record/source-pin.sha256" > "$record/source-pin.verify.txt"
test -z "$(git status --porcelain=v1)"

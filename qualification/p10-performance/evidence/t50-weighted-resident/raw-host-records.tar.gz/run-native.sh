#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/weighted-resident"
record="$base/$1"
mkdir "$record"
cd "$root/pancake"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/target/weighted-resident-cpu"
git rev-parse HEAD 'HEAD^{tree}' > "$record/source.txt"
git diff --binary > "$record/observer.patch"
sha256sum Cargo.lock "$base/native_probe.rs" "$record/observer.patch" > "$record/pins.sha256"
rustc +1.100.0 -Vv > "$record/rustc.txt"
cmd=(taskset -c 10,11 cargo +1.100.0 test --locked --offline -p pancake --lib "${2:-job::weighted_probe::}" -- --test-threads=1 --nocapture)
printf '%s\n' "cwd=$PWD" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUSTC_WRAPPER=unset" > "$record/command.txt"
printf '%q ' "${cmd[@]}" >> "$record/command.txt"
printf '\n' >> "$record/command.txt"
trap 'status=$?; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
date -u +%FT%TZ > "$record/start.txt"
/usr/bin/time -v -o "$record/resources.txt" "${cmd[@]}" > "$record/cargo.log" 2>&1

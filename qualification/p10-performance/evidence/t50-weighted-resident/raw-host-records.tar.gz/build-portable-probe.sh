#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/weighted-resident"
record="$base/portable-probe"
test "$(git rev-parse HEAD)" = a49ce692371558ff40f72b0af77f5249d00dcedb
test -z "$(git status --porcelain=v1)"
grep -qx 0 "$base/default-release/exit.txt"
sha256sum -c "$base/default-release/binary.sha256"
mkdir -p "$record"
restore() {
  cd "$root"
  git restore --worktree pancake/src/fusion/focus.rs pancake/src/job/mod.rs pancake/src/job/registration.rs pancake/src/job/stream.rs pancake/src/registration/kernels.rs
}
trap 'status=$?; restore; printf "%s\n" "$status" > "$record/exit.txt"; date -u +%FT%TZ > "$record/end.txt"' EXIT
python3 "$base/instrument.py" green
sed -i 's@weighted-resident/native_probe\.rs@weighted-resident/vulkan_stack_probe.rs@' pancake/src/job/mod.rs
cat >> pancake/src/fusion/focus.rs <<'RS'

#[cfg(test)]
#[path = "../../../artifacts/weighted-resident/vulkan_input_probe.rs"]
mod weighted_input_probe;
RS
git diff --check
git diff --binary > "$record/observer.patch"
sha256sum pancake/Cargo.lock "$base"/vulkan_{stack,input}_probe.rs "$record/observer.patch" > "$record/source-pin.sha256"
git rev-parse HEAD 'HEAD^{tree}' > "$record/source-tree.txt"

cd "$root/pancake"
unset CUDARC_CUDA_VERSION RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/target/weighted-resident-cpu"
cmd=(taskset -c 10,11 cargo +1.100.0 test --locked --offline --release -p pancake --lib --no-run --message-format json)
printf '%q ' "${cmd[@]}" > "$record/build.command"
printf '\n' >> "$record/build.command"
date -u +%FT%TZ > "$record/start.txt"
/usr/bin/time -v -o "$record/build-resources.txt" "${cmd[@]}" > "$record/build.jsonl" 2> "$record/build.log"
binary=$(jq -er 'select(.reason=="compiler-artifact" and .target.name=="pancake" and .profile.test and .executable) | .executable' "$record/build.jsonl")
test -x "$binary"
sha256sum "$binary" > "$record/binary.sha256"
readelf -n "$binary" > "$record/elf-notes.txt"
restore
test -z "$(git status --porcelain=v1)"

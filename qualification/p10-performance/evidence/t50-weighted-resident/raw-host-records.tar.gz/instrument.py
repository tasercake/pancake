from pathlib import Path
import sys

variant = sys.argv[1]
assert variant in ("red", "green")

def edit(name, substitutions):
    path = Path("pancake/src") / name
    code = path.read_text()
    for old, new in substitutions:
        assert code.count(old) == 1, (name, old)
        code = code.replace(old, new)
    path.write_text(code)

probe = "crate::job::weighted_probe"

def observe(indent, event):
    return f"{indent}#[cfg(test)]\n{indent}{probe}::record({probe}::Event::{event});\n"

edit("job/mod.rs", [("mod events;", 'mod events;\n#[cfg(test)]\n#[path = "../../../artifacts/weighted-resident/native_probe.rs"]\npub(crate) mod weighted_probe;')])
needle = "    let mut alignment = Alignment::new("
edit("job/stream.rs", [(needle, f"    #[cfg(test)]\n    let retain_input = retain_input && !{probe}::force_host();\n" + needle)])
needle = "    let resident = retain_input.then("
edit("registration/kernels.rs", [(needle, observe("    ", "LumaUpload") + needle)])
needle = "            warp(device, frame(&image)?, map.original, self.canvas, budget)?"
edit("job/registration.rs", [(needle, f"            let warped = {needle.strip()};\n" + observe("            ", "Warp") + "            warped")])

resize = """            crate::fusion::resize(
                device,
                [image.width(), image.height()],
                [self.canvas.width(), self.canvas.height()],
                image.samples(),
                budget,
            )?"""
if variant == "green":
    edit("job/registration.rs", [(resize, "            let resized = " + resize.lstrip()
        + ";\n" + observe("            ", "Resize") + "            resized")])

weight = "        launch_energy(client, shape, frame, &self.luma, &self.energy, depth);"
combine = "        combine::launch("
sync = """        cubecl::future::block_on(client.sync_buffers([&self.image.handle, &self.scores.handle]))
            .map_err(|error| error.to_string())
"""
observed_sync = """        let completion = cubecl::future::block_on(client.sync_buffers([&self.image.handle, &self.scores.handle]))
            .map_err(|error| error.to_string());
        #[cfg(test)]
        if completion.is_ok() {
""" + observe("            ", "FrameWait") + """        }
        completion
"""
if variant == "red":
    upload = "        let frame = upload(&state.client, samples);"
    transfer = (upload, upload + "\n" + observe("        ", "FusionUpload").rstrip())
else:
    upload = "        let frame = resident.unwrap_or_else(|| upload(&state.client, samples));"
    transfer = (upload,
        f"        #[cfg(test)]\n        if resident.is_some() {{\n" + observe("            ", "Resident") +
        "        } else {\n" + observe("            ", "FusionUpload") + "        }\n" + upload)
edit("fusion/focus.rs", [transfer, (weight, weight + "\n" + observe("        ", "Weight").rstrip()),
    (combine, observe("        ", "Combine") + combine), (sync, observed_sync)])

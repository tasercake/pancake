taskset -c 10\,11 cargo +1.100.0 clippy --locked --offline -p pancake --lib --test cpu_job --test cpu_advanced_fusion --test cpu_fusion_contract --test cpu_stack_plan -- -D warnings 

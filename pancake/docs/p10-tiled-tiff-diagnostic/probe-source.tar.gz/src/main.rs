#![allow(dead_code)]
mod native;
mod streamed;

use std::{env, hint::black_box, path::Path, time::Instant};

fn main() -> Result<(), String> {
    let mut args = env::args().skip(1);
    let mode = args.next().ok_or("missing mode")?;
    let sequence = match mode.as_str() {
        "native" => &[false][..],
        "streamed" => &[true][..],
        "alternating" => &[false, true, true, false, false, true][..],
        _ => return Err("unknown mode".to_owned()),
    };
    for arg in args {
        let path = Path::new(&arg);
        let mut reference: Option<Vec<u32>> = None;
        for &stream in sequence {
            let start = Instant::now();
            let (kind, width, height, values) = if stream {
                let frame = streamed::decode(black_box(path))?;
                ("streamed", frame.width(), frame.height(), frame.into_samples())
            } else {
                let frame = native::decode(black_box(path))?;
                ("native", frame.width(), frame.height(), frame.into_samples())
            };
            let seconds = start.elapsed().as_secs_f64();
            assert_eq!((width, height, values.len()), (6000, 4000, 72_000_000));
            println!("{arg}\t{kind}\t{seconds:.9}");
            if mode == "alternating" {
                if let Some(codes) = &reference {
                    assert!(values.iter().map(|v| v.to_bits()).eq(codes.iter().copied()));
                } else {
                    reference = Some(values.iter().map(|v| v.to_bits()).collect::<Vec<_>>());
                }
            }
            black_box(values);
        }
    }
    Ok(())
}

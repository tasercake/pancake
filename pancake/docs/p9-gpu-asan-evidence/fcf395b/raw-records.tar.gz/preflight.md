# Integrated Linux GPU AddressSanitizer replay

The replay is prepared for clean source
`fcf395b280f9cbdd4b4ee8c7ea41d40523c1c722` with Cargo.lock SHA-256
`f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc`.
The core, GPU tests, dependencies, and GPU sanitizer selector match the
sealed `12f2151` candidate. The earlier C and Rust receipts reproduce
distinct device acquisition and leak outcomes. A successful request may
still produce a failed sanitizer process.

## Commands after the respective host release

```sh
bash artifacts/p9-gpu-asan-prep/replay.sh build
bash artifacts/p9-gpu-asan-prep/replay.sh run
```

Build only after the CPU lease releases. The build uses three compile jobs,
four physical CPU cores, the pinned Rust nightly with rebuilt standard
library, a locked graph, and the ordinary six-target GPU selector. It
compiles the unchanged test executables without running them. A disposable
copy of the same workspace and lock builds the archived safe Rust control
as an example. Crate-use imports satisfy the copied workspace's lints. Two
standalone C controls use the existing archived Vulkan source. Retain the
exact executable digests and linked ELF build IDs.

Begin the runtime stage only after the RTX lease releases. Each process uses
the recorded NVIDIA 580.178.04 host and ICD, a private D-Bus session and caches,
and default sanitizer options. The inherited layer overrides and desktop
session variables are scrubbed. The expected focused runtime is explicit
`wgpu-vulkan` on the physical RTX 3090 at `0000:01:00.0`. The script records
commands, independent hardware identity, capped logs with the full-stream
checksums, and exact process exits.

| Observation | Proof |
| --- | --- |
| Unchanged production Vulkan acquisition and real kernel | `gpu_runtime_contract::explicit_gpu_override_completes_on_named_runtime` writes its fresh physical receipt only after wgpu selection, no-fallback checks, the exact `[2, 8, 14]` blur, and synchronization. Record both the assertion and process verdicts. |
| Minimal wgpu acquisition | Archived Rust control prints `minimal_wgpu_device=ok` with the actual adapter after requesting and releasing the device. |
| Direct CubeCL acquisition and kernel | A separate process uses the same Rust control binary to request Vulkan through CubeCL and prints `pinned_cubecl_kernel=ok` after its independent sample check. |
| External allocation control | Archived C runs print `vkCreateDevice=0` if successful. Capture both native and GCC ASan process verdicts under the same discovery conditions. |
| Complete integrated GPU sanitizer scope | Run `bash scripts/check.sh sanitizer-gpu address` unchanged. Record its exit and the reached test targets. |

A failed acquisition has no completed application kernel receipt.
A completed kernel with an LSan report still fails that sanitizer process.
Treat an unknown allocation stack as unclassified until the available
symbols or a same-driver control identify the allocation path. The C probe
reproducing an external leak independently leaves attribution of the Rust
reports open unless their traces support the same path. If the minimal Rust
request succeeds and the direct CubeCL route still rejects device creation,
a subsequent scratch-only build can isolate features, limits, memory hints
and experimental flags one field at a time. Retain the primary results
separately from that descriptor experiment.

The preliminary reservation is 3–5 minutes for CPU builds and roughly 30–90
seconds of exclusive GPU execution once ready. A timeout or failed earlier
test may leave later full-gate targets unrun. Report that status explicitly.

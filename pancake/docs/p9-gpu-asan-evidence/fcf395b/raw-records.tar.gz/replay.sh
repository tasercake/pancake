#!/usr/bin/env bash
set -euo pipefail

revision=fcf395b280f9cbdd4b4ee8c7ea41d40523c1c722
toolchain=nightly-2026-11-15
target=x86_64-unknown-linux-gnu
icd=/usr/share/vulkan/icd.d/nvidia_icd.json
case "$#" in 1) ;; *) printf 'Use build or run after the host is released.\n' >&2; exit 2 ;; esac
root=$(git rev-parse --show-toplevel)
prep="$root/artifacts/p9-gpu-asan-prep"
record="$prep/results"
source="$root/pancake"
controls="$source/docs/p0-sanitizer-evidence"
test "$(git rev-parse HEAD)" = "$revision"
test -z "$(git status --porcelain=v1)"
test "$(sha256sum "$source/Cargo.lock" | cut -d' ' -f1)" = f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc

export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$source/target/host-sanitizer-gpu-address"
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
rust=(cargo "+$toolchain")
common=(-Zbuild-std --locked --target "$target" --workspace --all-features)

case "$1" in
    build)
        test ! -e "$record"
        install -d -m 700 "$record"
        git rev-parse HEAD > "$record/source-revision.txt"
        git rev-parse HEAD^{tree} > "$record/source-tree.txt"
        sha256sum "$source"/{Cargo.toml,Cargo.lock,scripts/check.sh,scripts/assurance_targets.py,tests/gpu_runtime_contract.rs} \
            "$controls"/{rust-device-probe.rs,vulkan-device-probe.c} > "$record/source.sha256"
        rustup run "$toolchain" rustc -Vv > "$record/rustc.txt"
        gcc --version > "$record/gcc.txt"
        uname -a > "$record/os.txt"
        lscpu -p=CPU,CORE,SOCKET > "$record/cpu-topology.csv"

        cd "$source"
        cargo metadata --locked --no-deps --format-version 1 > "$record/target-metadata.json"
        python3 scripts/assurance_targets.py "$record/target-metadata.json" gpu > "$record/gpu-targets.txt"
        args=()
        while IFS= read -r name; do args+=(--test "$name"); done < "$record/gpu-targets.txt"
        RUSTFLAGS='-Dwarnings -Zsanitizer=address' timeout --kill-after=10s 1200s taskset --cpu-list 0,1,2,3 \
            "${rust[@]}" test "${common[@]}" "${args[@]}" --no-run --message-format=json \
            > "$record/app-build.jsonl" 2> "$record/app-build.log"
        python3 - "$record" <<'PY'
import json
from pathlib import Path
import sys

record = Path(sys.argv[1])
expected = set((record / "gpu-targets.txt").read_text().splitlines())
paths = {}
for line in (record / "app-build.jsonl").read_text().splitlines():
    artifact = json.loads(line)
    if artifact.get("reason") != "compiler-artifact" or not artifact.get("executable"):
        continue
    target = artifact["target"]
    if target["kind"] == ["test"] and target["name"] in expected:
        assert target["name"] not in paths
        paths[target["name"]] = artifact["executable"]
assert set(paths) == expected
(record / "test-executables.json").write_text(json.dumps(paths, indent=2) + "\n")
(record / "app-witness.path").write_text(paths["gpu_runtime_contract"] + "\n")
PY

        install -d "$record/control-tree"
        git -C "$root" archive "$revision" pancake | tar -x -C "$record/control-tree"
        diagnostic="$record/control-tree/pancake"
        example="$diagnostic/examples/p9_gpu_asan_control.rs"
        install -D -m 644 "$controls/rust-device-probe.rs" "$example"
        python3 - "$diagnostic/Cargo.toml" "$example" <<'PYTHON'
from pathlib import Path
import sys
import tomllib

manifest, example = map(Path, sys.argv[1:])
dependencies = tomllib.loads(manifest.read_text())["dependencies"]
with example.open("a") as source:
    # Keep the archived probe and satisfy the workspace example's crate-use lint.
    for crate in sorted(set(dependencies) - {"cubecl"}):
        rust_name = crate.replace("-", "_")
        source.write(f"\nuse ::{rust_name} as _;")
    source.write("\n")
PYTHON
        sha256sum "$example" > "$record/rust-control-source.sha256"
        cmp "$source/Cargo.lock" "$diagnostic/Cargo.lock"
        (
            cd "$diagnostic"
            RUSTFLAGS='-Dwarnings -Zsanitizer=address' timeout --kill-after=10s 1200s taskset --cpu-list 0,1,2,3 \
                "${rust[@]}" build "${common[@]}" --example p9_gpu_asan_control > "$record/rust-build.log" 2>&1
        )
        cmp "$source/Cargo.lock" "$diagnostic/Cargo.lock"
        gcc -Wall -Wextra -Werror -g "$controls/vulkan-device-probe.c" -o "$record/c-native" -lvulkan > "$record/c-native-build.log" 2>&1
        gcc -Wall -Wextra -Werror -g -fsanitize=address -fno-omit-frame-pointer \
            "$controls/vulkan-device-probe.c" -o "$record/c-address" -lvulkan > "$record/c-address-build.log" 2>&1
        rust_control="$CARGO_TARGET_DIR/$target/debug/examples/p9_gpu_asan_control"
        app_witness=$(cat "$record/app-witness.path")
        sha256sum "$rust_control" "$app_witness" "$record"/c-{native,address} > "$record/executables.sha256"
        readelf -n "$rust_control" "$app_witness" "$record"/c-{native,address} > "$record/build-ids.txt"
        ;;
    run)
        test ! -e "$record/run-started.txt"
        sha256sum --check "$record/executables.sha256" > "$record/executable-check.log"
        sha256sum "$icd" "$(readlink -f /usr/lib/x86_64-linux-gnu/libvulkan.so.1)" > "$record/vulkan.sha256"
        test "$(sha256sum "$icd" | cut -d' ' -f1)" = 7bdb6f27d35b66fc848df6f94b8773bba30ea3a7f06f114100d14154a235a34b
        nvidia-smi --query-gpu=name,uuid,pci.bus_id,driver_version --format=csv,noheader > "$record/nvidia.txt"
        rg -q '^NVIDIA GeForce RTX 3090, GPU-c7900bb5-e779-c07b-a37d-4adff841c8ac, 00000000:01:00.0, 580.178.04$' "$record/nvidia.txt"
        dpkg-query -W -f='${binary:Package}\t${Version}\n' libvulkan1:amd64 > "$record/loader-package.txt"
        date --iso-8601=seconds > "$record/run-started.txt"
        install -d -m 700 "$record/xdg" "$record/compute-cache"
        cd "$source"
        isolated=(env -u ASAN_OPTIONS -u LSAN_OPTIONS -u TSAN_OPTIONS -u UBSAN_OPTIONS
            -u LD_PRELOAD -u LD_LIBRARY_PATH -u DISPLAY -u WAYLAND_DISPLAY -u XAUTHORITY
            -u DBUS_SESSION_BUS_ADDRESS -u DBUS_STARTER_ADDRESS -u DBUS_STARTER_BUS_TYPE
            -u SESSION_MANAGER -u AT_SPI_BUS_ADDRESS
            -u VK_ICD_FILENAMES -u VK_ADD_DRIVER_FILES -u VK_INSTANCE_LAYERS -u VK_LAYER_PATH -u VK_ADD_LAYER_PATH
            -u VK_LOADER_LAYERS_DISABLE -u VK_LOADER_LAYERS_ENABLE -u VK_LOADER_LAYERS_ALLOW -u VK_LOADER_DEBUG
            -u PANCAKE_RUNTIME -u PANCAKE_TEST_GPU_RUNTIME -u PANCAKE_TEST_REQUIRE_AUTO_CPU -u PANCAKE_TEST_RUNTIME_RECEIPT
            -u CUBECL_WGPU_DEFAULT_DEVICE -u CUBECL_WGPU_MAX_TASKS -u WGPU_BACKEND
            "XDG_RUNTIME_DIR=$record/xdg" "VK_DRIVER_FILES=$icd")
        capture() {
            local name=$1 limit=$2 code=0
            shift 2
            local cache="$record/compute-cache/$name"
            install -d -m 700 "$cache"
            local -a run=("${isolated[@]}" "XDG_CACHE_HOME=$cache" "PANCAKE_COMPUTE_CACHE_DIR=$cache" \
                dbus-run-session -- taskset --cpu-list 0,1,2,3 timeout --kill-after=5s "$limit" "$@")
            printf '%q ' "${run[@]}" > "$record/$name.command"
            printf '\n' >> "$record/$name.command"
            (
                "${run[@]}" || code=$?
                printf '%s\n' "$code" > "$record/$name.status"
            ) 2>&1 | python3 "$prep/capture-log.py" "$record/$name.log" "$record/$name-stream.json"
        }
        app_witness=$(cat "$record/app-witness.path")
        rust_control="$CARGO_TARGET_DIR/$target/debug/examples/p9_gpu_asan_control"
        capture app-witness 15s env PANCAKE_TEST_GPU_RUNTIME=wgpu \
            "PANCAKE_TEST_RUNTIME_RECEIPT=$record/app-witness-hardware.txt" \
            "$app_witness" explicit_gpu_override_completes_on_named_runtime --exact --include-ignored --nocapture
        capture rust-minimal-wgpu 15s "$rust_control" wgpu
        capture rust-cubecl 15s "$rust_control" cubecl
        capture c-native 10s "$record/c-native"
        capture c-address 10s "$record/c-address"
        capture gate 120s bash scripts/check.sh sanitizer-gpu address
        cmp "$record/gpu-targets.txt" target/assurance/selected-targets.txt
        date --iso-8601=seconds > "$record/run-finished.txt"
        ;;
    *)
        printf 'Use build or run.\n' >&2
        exit 2
        ;;
esac

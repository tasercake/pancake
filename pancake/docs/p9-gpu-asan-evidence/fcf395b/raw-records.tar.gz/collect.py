"""Verify exact control outcomes and archive the recorded streams."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import re
import tarfile

prep = Path("artifacts/p9-gpu-asan-prep")
record = prep / "results"
dest = Path("pancake/docs/p9-gpu-asan-evidence/fcf395b")
outcomes = {}
cases = {
    "app-witness": (1, (4868, 8), "Parent device is lost"),
    "rust-minimal-wgpu": (1, (2522, 5), "minimal_wgpu_device=ok"),
    "rust-cubecl": (1, (4868, 8), "Parent device is lost"),
    "c-native": (0, None, "vkCreateDevice=0"),
    "c-address": (1, (2522, 5), "vkCreateDevice=0"),
    "gate": (1, (4868, 8), "Parent device is lost"),
}
names = {}
for name, (status, leaks, marker) in cases.items():
    log = (record / f"{name}.log").read_bytes()
    text = log.decode()
    stream = json.loads((record / f"{name}-stream.json").read_text())
    assert stream == {"bytes_received": len(log), "bytes_recorded": len(log),
                      "truncated": False, "full_stream_sha256": sha256(log).hexdigest()}
    assert int((record / f"{name}.status").read_text()) == status and marker in text
    summary = re.search(r"SUMMARY: AddressSanitizer: (\d+) byte\(s\) leaked in (\d+) allocation", text)
    assert (tuple(map(int, summary.groups())) if summary else None) == leaks
    allocations = sorted(int(value) for value in re.findall(r"^\w+ leak of (\d+) byte", text, re.M))
    assert sum(allocations) == (leaks[0] if leaks else 0)
    assert len(allocations) == (leaks[1] if leaks else 0)
    names[name] = text
    entry = {"process_status": status, "observed_marker": marker,
             "leaked_allocations": len(allocations), "leaked_bytes": sum(allocations),
             "allocation_sizes": allocations, "log": f"{name}.log"}
    outcomes[name] = entry

assert outcomes["c-address"]["allocation_sizes"] == outcomes["rust-minimal-wgpu"]["allocation_sizes"]
for name in ("c-address", "rust-minimal-wgpu"):
    assert "libdbus-1.so.3+0x22ddf" in names[name]
for name in ("rust-cubecl", "app-witness", "gate"):
    assert "libnvidia-gpucomp.so.580.178.04" in names[name]
    assert outcomes[name]["allocation_sizes"] == outcomes["gate"]["allocation_sizes"]
assert "device_pci_bus_id: \"0000:01:00.0\"" in names["rust-minimal-wgpu"]
assert "adapter=NVIDIA GeForce RTX 3090 vendor=0x10de" in names["c-native"]
assert "adapter=NVIDIA GeForce RTX 3090 vendor=0x10de" in names["c-address"]
assert not (record / "app-witness-hardware.txt").exists()
assert "test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 3 filtered out" in names["app-witness"]
assert "test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out" in names["gate"]
targets = (record / "gpu-targets.txt").read_text().splitlines()
reached = re.findall(r"^ +Running tests/(gpu_\w+)\.rs ", names["gate"], re.M)
assert reached == ["gpu_advanced_fusion"] and len(targets) == 6
outcomes["gate"].update(selected_targets=targets, reached_targets=reached,
                        unrun_targets=sorted(set(targets) - set(reached)),
                        failing_executable_elf_build_id=re.search(
                            r"gpu_advanced_fusion-[a-f0-9]+\+[^)]+\) \(BuildId: ([a-f0-9]+)\)",
                            names["gate"])[1])
outcomes["app-witness"].update(failed_test="explicit_gpu_override_completes_on_named_runtime",
                               completed_hardware_receipt=False)

files = {path.name: path for path in record.iterdir()
         if path.is_file() and path.name not in {"c-native", "c-address"}}
for name in ("capture-log.py", "collect.py", "preflight.md", "replay.sh"):
    files[name] = prep / name
manifest = {}
archive = dest / "raw-records.tar.gz"
with archive.open("wb") as stream, gzip.GzipFile(
    filename="", mode="wb", fileobj=stream, mtime=0
) as compressed, tarfile.open(fileobj=compressed, mode="w|") as tar:
    for name, path in sorted(files.items()):
        manifest[name] = {"bytes": path.stat().st_size, "sha256": sha256(path.read_bytes()).hexdigest()}
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, mode="r:gz") as tar:
    assert set(tar.getnames()) == set(files)
    for member in tar.getmembers():
        assert member.isfile()
        contents = tar.extractfile(member).read()
        assert manifest[member.name] == {"bytes": len(contents), "sha256": sha256(contents).hexdigest()}

source = (record / "source-revision.txt").read_text().strip()
assert source == "fcf395b280f9cbdd4b4ee8c7ea41d40523c1c722"
lock = sha256(Path("pancake/Cargo.lock").read_bytes()).hexdigest()
assert lock == "f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc"
receipt = {
    "source_revision": source,
    "source_tree": (record / "source-tree.txt").read_text().strip(),
    "cargo_lock_sha256": lock,
    "toolchain": "nightly-2026-11-15",
    "rustc": (record / "rustc.txt").read_text().splitlines()[0],
    "gcc": (record / "gcc.txt").read_text().splitlines()[0],
    "cpu_affinity": [0, 1, 2, 3],
    "compile_jobs": 3,
    "host": (record / "os.txt").read_text().strip(),
    "gpu": (record / "nvidia.txt").read_text().strip(),
    "loader_package": (record / "loader-package.txt").read_text().strip(),
    "runtime_options": {"asan": None, "lsan": None, "suppressions": []},
    "inputs": "Repository test fixtures and archived C and Rust startup controls",
    "run_started": (record / "run-started.txt").read_text().strip(),
    "run_finished": (record / "run-finished.txt").read_text().strip(),
    "results": outcomes,
    "raw_archive": {"file": archive.name, "sha256": sha256(archive.read_bytes()).hexdigest(), "files": manifest},
}
(dest / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(files)} raw records. Archive SHA-256 {receipt['raw_archive']['sha256']}")

"""Drain the complete process stream and preserve a bounded report."""
from hashlib import sha256
import json
from pathlib import Path
import sys

output, receipt = map(Path, sys.argv[1:])
maximum = 32 * 1024 * 1024
received = 0
recorded = 0
digest = sha256()
with output.open("wb") as log:
    while block := sys.stdin.buffer.read(65536):
        received += len(block)
        digest.update(block)
        if recorded < maximum:
            recorded += log.write(block[: maximum - recorded])
receipt.write_text(json.dumps({
    "bytes_received": received,
    "bytes_recorded": recorded,
    "truncated": received != recorded,
    "full_stream_sha256": digest.hexdigest(),
}, indent=2) + "\n")

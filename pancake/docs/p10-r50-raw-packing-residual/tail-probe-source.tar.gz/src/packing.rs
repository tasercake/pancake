use rawler::imgop::convert_from_f32_scaled_u16;
use rayon::prelude::{ParallelIterator, ParallelSliceMut};

const RAW_PACKING_CHUNK: usize = 64 * 1024;
const RAW_PARALLEL_MIN_SAMPLES: usize = 16 * RAW_PACKING_CHUNK;

/// Process disjoint slices in place, parallelizing only inside the installed RAW pool.
pub(super) fn for_each_packing_chunk(
    samples: &mut [f32],
    pool: Option<&rayon::ThreadPool>,
    process: impl Fn(&mut [f32]) + Send + Sync,
) {
    if samples.len() >= RAW_PARALLEL_MIN_SAMPLES
        && pool.is_some_and(|pool| {
            pool.current_thread_index().is_some() && pool.current_num_threads() > 1
        })
    {
        samples.par_chunks_mut(RAW_PACKING_CHUNK).for_each(process);
    } else {
        samples.chunks_mut(RAW_PACKING_CHUNK).for_each(process);
    }
}

/// Preserve the pinned Rawler quantization in one bounded working slice.
pub(super) fn pack_raw_rgb16_chunk(chunk: &mut [f32]) {
    let codes = convert_from_f32_scaled_u16(chunk, 0, u16::MAX);
    let white = f32::from(u16::MAX);
    for (sample, code) in chunk.iter_mut().zip(codes) {
        *sample = f32::from(code) / white;
    }
}


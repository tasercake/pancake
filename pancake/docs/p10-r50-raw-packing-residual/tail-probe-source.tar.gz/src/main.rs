mod packing;

use std::hint::black_box;
use std::thread;
use std::time::Instant;

use packing::{for_each_packing_chunk, pack_raw_rgb16_chunk};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mode = std::env::args().nth(1).ok_or("provide alternating, serial or pool")?;
    let rounds: &[bool] = match mode.as_str() {
        "alternating" => &[false, true, true, false, true, false, false, true],
        "serial" => &[false],
        "pool" => &[true],
        _ => return Err("unknown mode".into()),
    };
    let host_cpus = thread::available_parallelism()?.get();
    let workers = host_cpus.saturating_sub(1).clamp(1, 15);
    let pool = rayon::ThreadPoolBuilder::new().num_threads(workers).build()?;
    let samples = 51_775_488;
    let input: Vec<_> = (0..=u16::MAX)
        .cycle()
        .take(samples)
        .map(|code| (f32::from(code) + 0.5) / f32::from(u16::MAX))
        .collect();
    let mut output_reference: Option<Vec<u32>> = None;
    for &use_pool in rounds {
        let mut working = input.clone();
        let elapsed = pool.install(|| {
            let start = Instant::now();
            for_each_packing_chunk(
                black_box(&mut working),
                use_pool.then_some(&pool),
                pack_raw_rgb16_chunk,
            );
            start.elapsed()
        });
        if let Some(reference) = &output_reference {
            if !working
                .iter()
                .map(|sample| sample.to_bits())
                .eq(reference.iter().copied())
            {
                return Err("candidate and serial quantization differ bit for bit".into());
            }
        } else if mode == "alternating" {
            output_reference = Some(working.iter().map(|sample| sample.to_bits()).collect::<Vec<_>>());
        }
        black_box(working);
        println!(
            "{}\t{samples}\t{workers}\t{:.9}",
            if use_pool { "pool" } else { "serial" },
            elapsed.as_secs_f64()
        );
    }
    Ok(())
}

taskset --cpu-list 20\,21 cargo +1.100.0 test --locked --offline -p pancake --lib fusion::advanced::tests::native_resident_hybrid_consumes_only_validated_device_input -- --exact --test-threads=1 

taskset --cpu-list 20\,21 cargo +1.100.0 test --locked --offline -p pancake --test cpu_advanced_fusion --test cpu_job -- --test-threads=1 

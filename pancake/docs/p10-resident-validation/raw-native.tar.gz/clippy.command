taskset --cpu-list 20\,21 cargo +1.100.0 clippy --locked --offline -p pancake --lib --test cpu_advanced_fusion --test cpu_job -- -D warnings 

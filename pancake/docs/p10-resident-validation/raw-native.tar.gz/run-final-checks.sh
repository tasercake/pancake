#!/usr/bin/env bash
set -euo pipefail
proof=../artifacts/t50-resident-validation
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_TARGET_DIR="$PWD/target/resident-validation"
test -z "$(git status --porcelain=v1)"
run() {
    local arm=$1 status
    shift
    printf '%q ' "$@" > "$proof/$arm.command"
    printf '\n' >> "$proof/$arm.command"
    date --iso-8601=seconds > "$proof/$arm.start"
    status=0
    "$@" > "$proof/$arm.log" 2>&1 || status=$?
    printf '%s\n' "$status" > "$proof/$arm.status"
    date --iso-8601=seconds > "$proof/$arm.end"
    tail -15 "$proof/$arm.log"
    return "$status"
}
run integration taskset --cpu-list 20,21 cargo +1.100.0 test --locked --offline -p pancake --test cpu_advanced_fusion --test cpu_job -- --test-threads=1
policy="$PWD/target/dependency-policy"
mkdir -p "$policy"
taskset --cpu-list 20,21 cargo +1.100.0 metadata --offline --locked --format-version 1 --all-features > "$policy/metadata.json"
python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json --metadata "$policy/metadata.json" --effective-config "$policy/deny-effective.toml" --license-inventory "$policy/licenses.json" --clippy-config clippy.toml --effective-clippy-dir "$policy/clippy" > "$proof/dependency-policy.log"
export CLIPPY_CONF_DIR="$policy/clippy"
run clippy taskset --cpu-list 20,21 cargo +1.100.0 clippy --locked --offline -p pancake --lib --test cpu_advanced_fusion --test cpu_job -- -D warnings

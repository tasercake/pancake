#!/usr/bin/env bash
set -euo pipefail
proof=../artifacts/t50-resident-validation
arm=${1:?expected evidence arm}
export RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_TARGET_DIR="$PWD/target/resident-validation"
cmd=(taskset --cpu-list 20,21 cargo +1.100.0 test --locked --offline -p pancake --lib fusion::advanced::tests::native_resident_hybrid_consumes_only_validated_device_input -- --exact --test-threads=1)
printf '%q ' "${cmd[@]}" > "$proof/$arm.command"
printf '\n' >> "$proof/$arm.command"
date --iso-8601=seconds > "$proof/$arm.start"
set +e
"${cmd[@]}" > "$proof/$arm.log" 2>&1
status=$?
set -e
printf '%s\n' "$status" > "$proof/$arm.status"
date --iso-8601=seconds > "$proof/$arm.end"
tail -17 "$proof/$arm.log"
exit "$status"

taskset --cpu-list 4,5 cargo +1.100.0 test --locked --offline -p pancake --lib packed_witness_exact_decisions -- --test-threads=1

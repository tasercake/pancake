taskset --cpu-list 4,5 cargo +1.100.0 check --locked --offline -p pancake --example d150_anchor_skip_probe

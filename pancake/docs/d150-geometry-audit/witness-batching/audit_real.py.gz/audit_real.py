"""Bind observed proxy losses and rank support to the prior frozen-input witness."""
import gzip
import hashlib
import json
from pathlib import Path
from statistics import median

root = Path.cwd()
proof = root / "pancake/docs/d150-geometry-audit"
scratch = root / "artifacts/d150-batched-witness"
prior = proof / "witness-pilot/real-results.json.gz"
current = scratch / "real-packed.json"
before = json.loads(gzip.decompress(prior.read_bytes()))
after = json.loads(current.read_bytes())
assert before["proxy_extent"] == after["proxy_extent"] == [384,288]
assert before["candidate_order"] == after["candidate_order"]
assert before["loss_axes"] == after["loss_axes"]
assert len(before["comparisons"]) == len(after["comparisons"]) == 6
times = []
edge_summary = []
max_prior_loss_error = 0.0
for old, new in zip(before["comparisons"], after["comparisons"]):
    assert old["interval"] == new["interval"]
    assert old["native_oracles"] == new["native_oracles"]
    op, np = old["proxy"], new["proxy"]
    assert op["support"] == np["support"]
    assert op["moment_dispatches"] == np["serial_dispatches"] == 108
    assert np["packed_dispatches"] == 2
    assert np["bit_identical_scalar_moments"] == 540
    assert len(op["cells"]) == len(np["cells"]) == 9
    for old_cell, new_cell in zip(op["cells"], np["cells"]):
        assert old_cell["origin_proxy"] == new_cell["origin_proxy"]
        assert old_cell["strict_winner"] == new_cell["strict_winner"]
        for old_direction, new_direction in zip(old_cell["losses"], new_cell["losses"]):
            for old_candidate, new_candidate in zip(old_direction, new_direction):
                for a, b in zip(old_candidate, new_candidate):
                    if a is None or b is None:
                        assert a is b
                    else:
                        max_prior_loss_error = max(max_prior_loss_error, abs(a-b))
    rows = np["warmed_moment_pairs_ns"]
    assert len(rows) == 7 and all(len(pair) == 2 for pair in rows)
    times.extend(rows)
    edge_summary.append({
        "interval": new["interval"],
        "support": np["support"],
        "serial_median_ns": median(row[0] for row in rows),
        "packed_median_ns": median(row[1] for row in rows),
    })
assert max_prior_loss_error == 0.0
assert edge_summary[1]["support"][1]["supporting_cells"] == 8
assert edge_summary[1]["support"][1]["rank_two_footprint"]
assert all(not row["rank_two_footprint"] for row in edge_summary[4]["support"])
serial, packed = zip(*times)
summary = {
    "prior_results_sha256": hashlib.sha256(prior.read_bytes()).hexdigest(),
    "results_sha256": hashlib.sha256(current.read_bytes()).hexdigest(),
    "proxy_extent": after["proxy_extent"],
    "prior_max_abs_loss_error": max_prior_loss_error,
    "prior_geometry_and_all_support_unchanged": True,
    "one_to_one_bit_identical_scalar_moments": sum(
        row["proxy"]["bit_identical_scalar_moments"] for row in after["comparisons"]),
    "sample_pairs": len(times),
    "serial_median_ns": median(serial),
    "serial_range_ns": [min(serial), max(serial)],
    "packed_median_ns": median(packed),
    "packed_range_ns": [min(packed), max(packed)],
    "median_within_pair_ratio": median(b / a for a,b in times),
    "edge_summary": edge_summary,
}
(scratch / "real-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({key: value for key,value in summary.items() if key != "edge_summary"}, indent=2))

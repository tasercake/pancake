taskset --cpu-list 12\,13 cargo +1.100.0 test --locked --offline -p pancake-cli --test cpu_runtime_options jpeg_depth_warning_and_quality_describe_a_real_export -- --exact --test-threads=1 

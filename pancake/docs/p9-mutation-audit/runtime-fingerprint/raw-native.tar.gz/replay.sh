#!/usr/bin/env bash
set -euo pipefail
arm=${1:?red or green}
root="$PWD"
proof="$root/artifacts/runtime-fingerprint-audit"
source="$root/pancake/src/runtime/mod.rs"
test -z "$(git status --porcelain=v1)"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="$root/pancake/target/runtime-fingerprint" RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export CARGO_ENCODED_RUSTFLAGS=$'--cap-lints\x1fwarn'
if [[ $arm = red ]]; then
    cp "$source" "$proof/stock-runtime.rs.txt"
    trap 'cp "$proof/stock-runtime.rs.txt" "$source"' EXIT
    patch --batch --forward --fuzz=0 "$source" "$proof/survived.patch" > "$proof/red-apply.log"
    git diff -- pancake/src/runtime/mod.rs > "$proof/reproduced-mutant.patch"
fi
sha256sum "$source" "$root/pancake/Cargo.lock" "$root/pancake/crates/pancake-cli/tests/cpu_runtime_options.rs" > "$proof/$arm-source.sha256"
cmd=(taskset --cpu-list 12,13 cargo +1.100.0 test --locked --offline -p pancake-cli --test cpu_runtime_options jpeg_depth_warning_and_quality_describe_a_real_export -- --exact --test-threads=1)
printf '%q ' "${cmd[@]}" > "$proof/$arm.command"
printf '\n' >> "$proof/$arm.command"
status=0
(cd pancake && "${cmd[@]}") > "$proof/$arm.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/$arm.status"
tail -18 "$proof/$arm.log"
if [[ $arm = red ]]; then
    test "$status" -eq 101
    rg -q 'completed CPU export lost its runtime compilation identity' "$proof/$arm.log"
else
    test "$status" -eq 0
    rg -q '1 passed; 0 failed' "$proof/$arm.log"
fi

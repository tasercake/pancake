#!/usr/bin/env bash
set -euo pipefail
artifact=$(cd "$(dirname "$0")" && pwd)
target=cpu_hybrid_commutes_with_transposition
pyramid=src/fusion/advanced/pyramid.rs
test "$(git rev-parse HEAD)" = 0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
git diff --exit-code -- "$pyramid"
TZ=Asia/Singapore date --iso-8601=seconds > "$artifact/start.sgt"
trap 'git restore --worktree -- "$pyramid"' EXIT

mutation() {
    local name=$1 status
    patch --batch --forward -p0 < "$artifact/exact-$name-mutant.diff" > "$artifact/$name-patch.log"
    set +e
    cargo +1.100.0 test --offline --locked -p pancake --test cpu_advanced_fusion "$target" \
        -- --exact --test-threads=1 > "$artifact/$name-native.log" 2>&1
    status=$?
    set -e
    printf '%s\n' "$status" > "$artifact/$name-native.exit"
    git restore --worktree -- "$pyramid"
    git diff --exit-code -- "$pyramid"
}

mutation row
rg "transposing the focus sources changed Hybrid by" "$artifact/row-native.log"
test "$(cat "$artifact/row-native.exit")" -eq 101
set +e
cargo +1.100.0 test --offline --locked -p pancake --test cpu_advanced_fusion -- \
    --test-threads=1 > "$artifact/stock-native.log" 2>&1
stock=$?
set -e
printf '%s\n' "$stock" > "$artifact/stock-native.exit"
tail -14 "$artifact/stock-native.log"
if ((stock != 0)); then
    exit "$stock"
fi
if test -f "$artifact/exact-top-right-mutant.diff"; then
    mutation top-right
    tail -23 "$artifact/top-right-native.log"
fi
mkdir -p target/dependency-policy
cargo +1.100.0 metadata --offline --locked --format-version 1 --all-features > target/dependency-policy/metadata.json
python3 scripts/dependency_policy.py --config deny.toml --ledger dependency-policy.json \
    --metadata target/dependency-policy/metadata.json \
    --effective-config target/dependency-policy/deny-effective.toml \
    --license-inventory target/dependency-policy/licenses.json --clippy-config clippy.toml \
    --effective-clippy-dir target/dependency-policy/clippy > "$artifact/dependency-policy.log" 2>&1
set +e
CLIPPY_CONF_DIR="$PWD/target/dependency-policy/clippy" \
    cargo +1.100.0 clippy --offline --locked -p pancake --test cpu_advanced_fusion -- --no-deps -D warnings \
    > "$artifact/clippy.log" 2>&1
lint=$?
set -e
printf '%s\n' "$lint" > "$artifact/clippy.exit"
tail -12 "$artifact/clippy.log"
TZ=Asia/Singapore date --iso-8601=seconds > "$artifact/end.sgt"
exit "$lint"

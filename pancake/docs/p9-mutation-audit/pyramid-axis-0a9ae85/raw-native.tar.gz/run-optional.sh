#!/usr/bin/env bash
set -euo pipefail
artifact=$(cd "$(dirname "$0")" && pwd)
pyramid=src/fusion/advanced/pyramid.rs
target=cpu_hybrid_commutes_with_transposition
test "$(git rev-parse HEAD)" = 0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
test "$(cat "$artifact/stock-native.exit")" -eq 0
git diff --exit-code -- "$pyramid"
trap 'git restore --worktree -- "$pyramid"' EXIT
for name in bottom-right bottom-lerp; do
    time_sgt=$(TZ=Asia/Singapore date +%H%M)
    if ((10#$time_sgt >= 237)); then
        printf '%s\n' "not launched before quiet window" > "$artifact/$name-native.status"
        continue
    fi
    patch --batch --forward -p0 < "$artifact/exact-$name-mutant.diff" > "$artifact/$name-patch.log"
    set +e
    cargo +1.100.0 test --offline --locked -p pancake --test cpu_advanced_fusion "$target" \
        -- --exact --test-threads=1 > "$artifact/$name-native.log" 2>&1
    status=$?
    set -e
    printf '%s\n' "$status" > "$artifact/$name-native.exit"
    git restore --worktree -- "$pyramid"
    git diff --exit-code -- "$pyramid"
    tail -18 "$artifact/$name-native.log"
done
TZ=Asia/Singapore date --iso-8601=seconds > "$artifact/optional-end.sgt"

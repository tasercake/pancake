/usr/bin/taskset -c 8\,9 cargo +1.100.0 test --offline --locked -p pancake --test cpu_registration_contract --jobs 2 cpu_affine_inverse_reverses_signed_shear -- --exact 

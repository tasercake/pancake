#!/usr/bin/env bash
set -euo pipefail
scope=$(realpath "$1")
cd "$(git rev-parse --show-toplevel)/pancake"
export CARGO_TARGET_DIR="$scope/target" CARGO_INCREMENTAL=0
export RUSTC_WRAPPER='' RUSTC_WORKSPACE_WRAPPER=''
base=(/usr/bin/taskset -c 8,9 cargo +1.100.0 test --offline --locked -p pancake --test cpu_registration_contract --jobs 2)
{
  git rev-parse HEAD 'HEAD^{tree}'
  sha256sum Cargo.lock "$scope/inverse.diff" "$scope/crop.diff"
  rustc +1.100.0 -vV
  uname -a
  taskset -c 8,9 sh -c 'sed -n "/^Cpus_allowed_list:/p" /proc/self/status'
} > "$scope/identity.txt"
run() {
  local label=$1
  shift
  printf '%q ' "${base[@]}" "$@" > "$scope/$label.command"
  printf '\n' >> "$scope/$label.command"
  local status=0
  "${base[@]}" "$@" > "$scope/$label.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$scope/$label.status"
}
replay() {
  local mutant=$1
  local test_name=$2
  local expected=$3
  patch --dry-run -p0 -i "$scope/$mutant.diff"
  patch -p0 -i "$scope/$mutant.diff"
  trap 'git restore --worktree -- src/registration/geometry.rs' EXIT
  test "$(git diff --name-only)" = 'pancake/src/registration/geometry.rs'
  git diff -- src/registration/geometry.rs > "$scope/$mutant-applied.diff"
  run "$mutant" "$test_name" -- --exact
  git restore --worktree -- src/registration/geometry.rs
  trap - EXIT
  test -z "$(git diff --name-only)"
  test "$(cat "$scope/$mutant.status")" = 101
  rg -Fq "$expected" "$scope/$mutant.log"
  run "stock-after-$mutant"
  test "$(cat "$scope/stock-after-$mutant.status")" = 0
}
replay inverse cpu_affine_inverse_reverses_signed_shear "signed shear inverse did not recover coordinates"
replay crop cpu_scaled_crop_uses_the_last_pixel_center "scaled last-pixel crop expected"
for arm in inverse stock-after-inverse crop stock-after-crop; do
    printf '%s\n' "$arm"
    tail -15 "$scope/$arm.log"
done

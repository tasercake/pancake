/usr/bin/taskset -c 8\,9 cargo +1.100.0 test --offline --locked -p pancake --test cpu_registration_contract --jobs 2 cpu_scaled_crop_uses_the_last_pixel_center -- --exact 

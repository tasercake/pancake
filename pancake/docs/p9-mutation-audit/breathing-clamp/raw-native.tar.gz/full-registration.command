taskset --cpu-list 12,13 cargo +1.100.0 test --locked --offline -p pancake --test cpu_registration_contract -- --test-threads=1

#!/usr/bin/env bash
set -euo pipefail
arm=${1:?red or green}
repo="$PWD"
folder="$repo/pancake/docs/d150-geometry-audit/anchor-skip-prereg"
proof="$repo/artifacts/d150-packed-empty"
archived="$repo/pancake/docs/d150-geometry-audit/witness-batching/real-overlay.patch.gz"
control="$folder/packed-control.patch.gz"
zero_overlap="$folder/packed-zero-overlap.patch.gz"
module="$repo/pancake/src/registration/real_packed_pilot.rs"
test -z "$(git status --porcelain)"
test ! -e "$module"
gzip -dc "$archived" | git apply --check
gzip -dc "$archived" | git apply
if ! gzip -dc "$control" | git apply; then gzip -dc "$archived" | git apply -R; exit 1; fi
if [[ $arm = green ]] && ! gzip -dc "$zero_overlap" | git apply; then
  gzip -dc "$control" | git apply -R
  gzip -dc "$archived" | git apply -R
  exit 1
fi
cp "$module" "$proof/$arm.original.rs.txt"
cleanup() {
  cp "$proof/$arm.original.rs.txt" "$module"
  if [[ $arm = green ]]; then gzip -dc "$zero_overlap" | git -C "$repo" apply -R; fi
  gzip -dc "$control" | git -C "$repo" apply -R
  gzip -dc "$archived" | git -C "$repo" apply -R
}
trap cleanup EXIT
printf '\n' >> "$module"
cat "$folder/zero-overlap-test.rs.txt" >> "$module"
export CARGO_TARGET_DIR="$repo/pancake/target/d150-packed-empty" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
export PANCAKE_PACKED_NEIGHBOR_REPORT="$proof/$arm-neighbor.json"
cmd=(taskset --cpu-list 4,5 cargo +1.100.0 test --locked --offline -p pancake --lib packed_witness_ -- --test-threads=1 --skip packed_witness_cpu_cost_diagnostic --skip packed_witness_real_d150_proxy_diagnostic)
printf '%q ' "${cmd[@]}" > "$proof/$arm.command"
printf '\n' >> "$proof/$arm.command"
git rev-parse HEAD > "$proof/$arm-source.txt"
status=0
(cd pancake && "${cmd[@]}") > "$proof/$arm.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/$arm.status"
tail -19 "$proof/$arm.log"
if [[ $arm = red ]]; then
  test "$status" -eq 101
  rg -q 'expected one to 54 bounded witness records per direction' "$proof/$arm.log"
else
  test "$status" -eq 0
  rg -q '2 passed; 0 failed' "$proof/$arm.log"
fi
test "$(jq -r .bit_identical_scalar_moments "$proof/$arm-neighbor.json")" -eq 540

#!/usr/bin/env bash
set -euo pipefail

tested=3dc9bcf3c30605badea2f7b2ee2840075507b6c3
test "$(git rev-parse HEAD)" = "$tested"
test -n "${CARGO_TARGET_DIR:?Use a reserved, idle app TSan cache}"
probe="$PWD/artifacts/oneshot-tsan"
export CARGO_BUILD_JOBS=2
cd pancake
sha256sum --check "$probe/candidate-app-manifests.sha256"
if env -u TSAN_OPTIONS -u ASAN_OPTIONS -u LSAN_OPTIONS \
    RUSTFLAGS='-Dwarnings -Zsanitizer=thread' \
    timeout --signal=TERM --kill-after=5s 420s taskset --cpu-list 0,1,2,3 \
    cargo +nightly-2026-11-15 test -Zbuild-std --locked --offline \
    --target x86_64-unknown-linux-gnu --workspace --all-features --test cpu_cli \
    -- --exact relative_glob_processes_the_selected_sources > "$probe/app-focused.log" 2>&1; then
    printf '0\n' > "$probe/app-focused.status"
else
    printf '%s\n' "$?" > "$probe/app-focused.status"
fi

if env -u TSAN_OPTIONS -u ASAN_OPTIONS -u LSAN_OPTIONS \
    timeout --signal=TERM --kill-after=5s 420s taskset --cpu-list 0,1,2,3 \
    bash scripts/check.sh sanitizer thread > "$probe/app-thread.log" 2>&1; then
    printf '0\n' > "$probe/app-thread.status"
else
    printf '%s\n' "$?" > "$probe/app-thread.status"
fi
cli="$CARGO_TARGET_DIR/x86_64-unknown-linux-gnu/debug/pancake-cli"
if test -f "$cli"; then
    sha256sum "$cli" > "$probe/app-cli.sha256"
    readelf -n "$cli" | rg 'Build ID:' > "$probe/app-cli-build-id.txt"
fi
cat "$probe/app-focused.status" "$probe/app-thread.status"
tail -n 22 "$probe/app-focused.log"
tail -n 22 "$probe/app-thread.log"

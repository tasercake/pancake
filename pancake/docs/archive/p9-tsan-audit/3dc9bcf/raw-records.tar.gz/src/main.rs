//! Select the already-sent blocking receive path without a second acquire.

use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;
use std::time::{Duration, Instant};

/// Read after publication and free the channel before joining the sender.
///
/// # Errors
///
/// Reports worker startup, handoff, deadline or join failures.
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let (sender, receiver) = oneshot::channel::<()>();
    let published = Arc::new(AtomicBool::new(false));
    let sender_marker = Arc::clone(&published);
    let worker = thread::Builder::new().name("probe-sender".to_owned()).spawn(move || {
        sender.send(()).map_err(|_| "startup publication failed")?;
        // The separate relaxed marker schedules the observed x86 path without
        // adding a synchronizes-with edge for the channel allocation.
        sender_marker.store(true, Ordering::Relaxed);
        Ok::<(), &'static str>(())
    })?;
    let start = Instant::now();
    while !published.load(Ordering::Relaxed) {
        if start.elapsed() > Duration::from_secs(10) {
            return Err("sender failed to publish before the probe deadline".into());
        }
        thread::yield_now();
    }
    receiver.recv()?;
    worker.join().map_err(|_| "probe sender exited with a panic")??;
    Ok(())
}

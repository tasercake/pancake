#!/usr/bin/env bash
set -euo pipefail
repo=$(git rev-parse --show-toplevel)
record="$repo/artifacts/native-cuda-11cfcf8"
retained=/home/krishna/Documents/focus-stacking/artifacts/pancake-linux-native/11cfcf8
expected=11cfcf8aac5921dfa843bfc5777eb4b2643a6ca6
locked=f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc
llvm_cache="${XDG_CACHE_HOME:-$HOME/.cache}/tracel"
llvm_data="${XDG_DATA_HOME:-$HOME/.local/share}/tracel/tracel-llvm-23.1.0-4"
[[ $(git rev-parse HEAD) == "$expected" ]]
[[ -z $(git status --porcelain=v1) ]]
[[ ! -e "$retained" ]]
[[ -x "$llvm_data/bin/llvm-config" ]]
[[ -r "$llvm_cache/tracel-llvm-23.1.0-4-linux-x64.tar.xz" ]]
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CUDARC_CUDA_VERSION=12050 CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$repo/pancake/target/native-cuda-11cfcf8"
export LD_LIBRARY_PATH=/usr/local/cuda-12.5/lib64
git rev-parse HEAD HEAD^{tree} HEAD:pancake > "$record/source.txt"
git status --porcelain=v1 > "$record/status-before.txt"
cd "$repo/pancake"
printf '%s  Cargo.lock\n' "$locked" | sha256sum -c
sha256sum Cargo.lock Cargo.toml crates/pancake-cli/Cargo.toml rust-toolchain.toml > "$record/input-files.sha256"
cargo +1.100.0 -Vv > "$record/cargo.txt"
rustc +1.100.0 -Vv > "$record/rustc.txt"
{
  uname -smr
  lscpu | sed -n '1,/^Vulnerabilities/p'
} > "$record/host.txt"
printf '%s\n' "cwd=$PWD" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR" "CUDARC_CUDA_VERSION=$CUDARC_CUDA_VERSION" "LD_LIBRARY_PATH=$LD_LIBRARY_PATH" "CARGO_INCREMENTAL=$CARGO_INCREMENTAL" "CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS" "CARGO_NET_OFFLINE=$CARGO_NET_OFFLINE" "RUSTC_WRAPPER=unset" > "$record/build-settings.txt"
command=(taskset --cpu-list 10,11 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli --bin pancake-cli -j 2 --features cubecl/cuda)
printf '%q ' "${command[@]}" > "$record/build.command"
printf '\n' >> "$record/build.command"
taskset --cpu-list 10,11 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli -e normal,build --features cubecl/cuda > "$record/cargo-graph.txt"
for dependency in cubecl-cuda cudarc cubecl-cpu cubecl-wgpu; do
  rg -q "\\b$dependency v" "$record/cargo-graph.txt"
done
if rg -n '\b(cubecl-hip|cubecl-metal|slint) v' "$record/cargo-graph.txt"; then
  printf 'Unexpected optional runtime or Slint in CUDA CLI dependency graph\n' >&2
  exit 1
fi
cp "$llvm_cache/tracel-llvm-23.1.0-4-linux-x64.checksums.json" "$record/llvm-publisher-checksums.json"
sha256sum "$llvm_cache/tracel-llvm-23.1.0-4-linux-x64.tar.xz" "$llvm_data/bin/llvm-config" > "$record/llvm-toolchain.sha256"
sha256sum \
  /usr/local/cuda-12.5/lib64/libnvrtc.so.12.5.40 \
  /usr/local/cuda-12.5/lib64/libnvrtc-builtins.so.12.5.40 \
  /usr/lib/x86_64-linux-gnu/libcuda.so.580.178.04 \
  /usr/local/cuda-12.5/nvvm/libdevice/libdevice.10.bc > "$record/cuda-runtime-files.sha256"
date --iso-8601=ns > "$record/build.start"
status=0
/usr/bin/time -v -o "$record/build.time" "${command[@]}" > "$record/build.log" 2>&1 || status=$?
date --iso-8601=ns > "$record/build.end"
printf '%s\n' "$status" > "$record/build.exit"
[[ "$status" == 0 ]]
binary="$CARGO_TARGET_DIR/release/pancake-cli"
[[ -x "$binary" ]]
readelf -W -h -n -d "$binary" > "$record/elf.txt"
nm -C --defined-only "$binary" > "$record/defined-symbols.txt"
{
  for namespace in cubecl_cuda:: cudarc:: cubecl_cpu:: cubecl_wgpu::; do
    printf '%s ' "$namespace"
    rg -Fc "$namespace" "$record/defined-symbols.txt"
    rg -F -m 2 "$namespace" "$record/defined-symbols.txt"
  done
} > "$record/link-witness.txt"
if rg -nm 1 'cubecl_hip::|cubecl_metal::' "$record/defined-symbols.txt"; then
  printf 'Unexpected optional backend in linked CLI\n' >&2
  exit 1
fi
git status --porcelain=v1 > "$record/status-after.txt"
[[ ! -s "$record/status-after.txt" ]]
mkdir "$retained"
cp --reflink=auto -- "$binary" "$retained/pancake-cli"
cmp -- "$binary" "$retained/pancake-cli"
chmod 0555 "$retained/pancake-cli"
(cd "$retained" && sha256sum pancake-cli) > "$record/pancake-cli.sha256"
cp "$record/pancake-cli.sha256" "$retained/pancake-cli.sha256"
chmod 0444 "$retained/pancake-cli.sha256"
stat --printf 'size_bytes=%s\nmode=%a\n' "$retained/pancake-cli" > "$record/pancake-cli.stat"
(cd "$retained" && sha256sum -c pancake-cli.sha256)

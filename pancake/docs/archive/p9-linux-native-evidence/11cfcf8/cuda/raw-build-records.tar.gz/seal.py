import hashlib
import json
import re
from pathlib import Path

record = Path(__file__).resolve().parent
retained = Path("/home/krishna/Documents/focus-stacking/artifacts/pancake-linux-native/11cfcf8")
binary = retained / "pancake-cli"


def read(name):
    return (record / name).read_text().strip()


def directory_hashes(name):
    return {
        path: digest
        for digest, path in (line.split(maxsplit=1) for line in read(name).splitlines())
    }


def content_hash(name):
    with (record / name).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


source, root_tree, pancake_tree = read("source.txt").splitlines()
elf_id = re.search(r"Build ID: ([0-9a-f]{40})", read("elf.txt")).group(1)
receipt = {
    "schema_version": 1,
    "scope": "release compile and link; CLI and device execution pending",
    "tested_revision": source,
    "source_tree": root_tree,
    "source_pancake_tree": pancake_tree,
    "source_clean_at_build": not read("status-before.txt") and not read("status-after.txt"),
    "cargo_lock_sha256": directory_hashes("input-files.sha256")["Cargo.lock"],
    "cargo_inputs_sha256": directory_hashes("input-files.sha256"),
    "rustc": read("rustc.txt"),
    "cargo": read("cargo.txt"),
    "logical_cpus": [10, 11],
    "parallel_build_jobs": 2,
    "cargo_feature": "cubecl/cuda",
    "cudarc_cuda_api": 12050,
    "build_command": read("build.command"),
    "build_settings": read("build-settings.txt"),
    "build_start": read("build.start"),
    "build_end": read("build.end"),
    "build_exit": int(read("build.exit")),
    "build_log_sha256": content_hash("build.log"),
    "dependency_graph_sha256": content_hash("cargo-graph.txt"),
    "link_witness_sha256": content_hash("link-witness.txt"),
    "cuda_runtime_files_sha256": directory_hashes("cuda-runtime-files.sha256"),
    "llvm_archive_sha256_matches_publisher": read("llvm-publisher-match.txt"),
    "elf": {
        "retained_local_path": str(binary),
        "size_bytes": binary.stat().st_size,
        "sha256": directory_hashes("pancake-cli.sha256")["pancake-cli"],
        "gnu_build_id": elf_id,
    },
    "physical_device_provenance": None,
}
if receipt["build_exit"] != 0 or not receipt["source_clean_at_build"]:
    raise RuntimeError("expected a clean successful build")
print(json.dumps(receipt, indent=2))

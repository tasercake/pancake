#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
proof="$root/artifacts/hip-release-11cfcf8"
test "$(git rev-parse HEAD)" = 11cfcf8aac5921dfa843bfc5777eb4b2643a6ca6
test -z "$(git status --porcelain --untracked-files=all)"
cd "$root/pancake"
sha256sum --check "$proof/source-pin.sha256" > "$proof/source-pin.verify.txt"
[[ $(cat "$proof/build.status") = 0 ]]
rg -q "Finished .release. profile" "$proof/build.log"
target="$PWD/target/hip-release"
graph=(taskset -c 12,13 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli -e normal,build --features cubecl/hip)
printf '%q ' "${graph[@]}" > "$proof/dependency-graph.command"
printf '\n' >> "$proof/dependency-graph.command"
"${graph[@]}" > "$proof/dependency-graph.txt" 2> "$proof/dependency-graph.stderr"
inverse=("${graph[@]}" -i cubecl-hip)
printf '%q ' "${inverse[@]}" > "$proof/dependency-inverse.command"
printf '\n' >> "$proof/dependency-inverse.command"
"${inverse[@]}" > "$proof/dependency-inverse.txt" 2> "$proof/dependency-inverse.stderr"
for required in 'cubecl-cpu v0.11.4' 'cubecl-wgpu v0.11.4' 'cubecl-hip v0.11.4' 'cubecl-hip-sys v7.14.6085001'; do
    rg -qF "$required" "$proof/dependency-graph.txt"
done
if rg -q 'cubecl-(cuda|metal) v|cudarc v|slint v|i-slint-[^ ]+ v' "$proof/dependency-graph.txt"; then
    printf '%s\n' 'Unexpected optional runtime or frontend in the selected HIP graph'
    exit 1
fi
rg -qF 'pancake-cli v0.1.0' "$proof/dependency-inverse.txt"
shopt -s nullglob
abi=("$target"/release/build/cubecl-hip-sys/*/run/stdout)
[[ ${#abi[@]} = 1 ]]
rg 'cargo:rustc-cfg=feature="hip_[0-9]+"' "${abi[0]}" > "$proof/hip-abi.txt"
[[ $(cat "$proof/hip-abi.txt") = 'cargo:rustc-cfg=feature="hip_60850"' ]]
cp "${abi[0]}" "$proof/hip-sys-build-output.txt"

binary="$target/release/pancake-cli"
[[ -x "$binary" ]]
sha256sum "$binary" > "$proof/binary.sha256"
stat -c '%s' "$binary" > "$proof/binary.bytes"
file "$binary" > "$proof/elf.txt"
readelf -W -h -n -d "$binary" > "$proof/elf-static.txt"
rg 'Build ID:' "$proof/elf-static.txt" > "$proof/elf-build-id.txt"
rg '\(NEEDED\)' "$proof/elf-static.txt" > "$proof/elf-needed.txt"
nm --defined-only --demangle "$binary" | awk '
  /cubecl_hip::/ { print; hip++ }
  /cubecl_hip_sys::/ { binding++ }
  /cubecl_cuda::/ { cuda++ }
  /cubecl_wgpu::/ { wgpu++ }
  /cubecl_cpu::/ { cpu++ }
  /[[:space:]](slint::|i_slint_[a-z_]+::)/ { frontend++ }
  END {
    print "symbol_counts: hip=" hip, "hip_bindings=" binding, "cuda=" (cuda+0), "wgpu=" wgpu, "cpu=" cpu, "frontend=" (frontend+0)
    exit !(hip>0 && binding>0 && cuda==0 && wgpu>0 && cpu>0 && frontend==0)
  }
' > "$proof/runtime-symbols.txt"
rg -q 'cubecl_hip::runtime|cubecl_hip::compute::server' "$proof/runtime-symbols.txt"
rg -q 'Advanced Micro Devices X86-64' "$proof/elf-static.txt"
{
  du -sb "$target"
  df -h "$PWD"
} > "$proof/host-resources.end.txt"
git status --porcelain --untracked-files=all > "$proof/source-status.end.txt"
[[ ! -s "$proof/source-status.end.txt" ]]
date -u +%FT%TZ > "$proof/verify.end"

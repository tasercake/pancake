#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
proof="$root/artifacts/hip-release-11cfcf8"
test "$(git rev-parse HEAD)" = 11cfcf8aac5921dfa843bfc5777eb4b2643a6ca6
test -z "$(git status --porcelain --untracked-files=all)"
cd "$root/pancake"
{
  date -u +%FT%TZ
  git rev-parse HEAD HEAD^{tree} HEAD:pancake
  sha256sum Cargo.lock Cargo.toml crates/pancake-cli/Cargo.toml
  uname -srm
  lscpu | awk '/^Model name:/'
  rustc +1.100.0 --version --verbose
  cargo +1.100.0 --version
} > "$proof/host-source.txt"
date -u +%FT%TZ > "$proof/build.start"
status=0
/usr/bin/time -v -o "$proof/build.time" env -u CUDARC_CUDA_VERSION -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER \
  CARGO_INCREMENTAL=0 CARGO_TARGET_DIR="$PWD/target/hip-release" \
  taskset -c 12,13 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli \
  --bin pancake-cli -j 2 --features cubecl/hip > "$proof/build.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/build.status"
date -u +%FT%TZ > "$proof/build.end"
tail -8 "$proof/build.log"
exit "$status"

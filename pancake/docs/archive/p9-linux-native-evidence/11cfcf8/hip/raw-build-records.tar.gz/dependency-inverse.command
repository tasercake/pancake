taskset -c 12\,13 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli -e normal\,build --features cubecl/hip -i cubecl-hip 

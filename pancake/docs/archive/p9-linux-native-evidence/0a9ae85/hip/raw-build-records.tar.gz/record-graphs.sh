#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/hip-link"
cd "$root/pancake"
cmd=(taskset -c 10,11 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli
  -e normal,build --features cubecl/hip)
printf '%q ' "${cmd[@]}" > "$record/dependency-graph.command"
printf '\n' >> "$record/dependency-graph.command"
"${cmd[@]}" > "$record/dependency-graph.txt" 2> "$record/dependency-graph.stderr"
inverse=("${cmd[@]}" -i cubecl-hip)
printf '%q ' "${inverse[@]}" > "$record/dependency-inverse.command"
printf '\n' >> "$record/dependency-inverse.command"
"${inverse[@]}" > "$record/dependency-inverse.txt" 2> "$record/dependency-inverse.stderr"

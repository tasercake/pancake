taskset -c 10\,11 cargo +1.100.0 tree --locked --offline -p pancake -p pancake-cli -e normal\,build --features cubecl/hip 

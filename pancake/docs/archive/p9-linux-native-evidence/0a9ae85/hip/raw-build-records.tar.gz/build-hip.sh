#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/hip-link"
test "$(git rev-parse HEAD)" = 0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
test -z "$(git status --porcelain=v1)"
cd "$root/pancake"
unset CUDARC_CUDA_VERSION RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_TARGET_DIR="$PWD/target/native-hip-release"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
trap 'status=$?; date -u +%FT%TZ > "$record/end.txt"; printf "%s\n" "$status" > "$record/exit.txt"' EXIT
date -u +%FT%TZ > "$record/start.txt"
git rev-parse HEAD 'HEAD^{tree}' 'HEAD:pancake' > "$record/source-tree.txt"
git status --porcelain=v1 > "$record/source-status.start.txt"
sha256sum Cargo.lock Cargo.toml crates/pancake-cli/Cargo.toml > "$record/source-pin.sha256"
grep -qF 'f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc  Cargo.lock' "$record/source-pin.sha256"
{
  uname -srmo
  lscpu | grep -E '^Architecture|^CPU\(s\):|^Model name|^Thread\(s\) per core'
  taskset -c 10,11 bash -c "grep Cpus_allowed_list /proc/self/status"
  df -h "$PWD"
  free -h
} > "$record/host-resources.start.txt"
{
  cargo +1.100.0 -Vv
  rustc +1.100.0 -Vv
  cc --version
  ld --version
  nm --version
  readelf --version
} > "$record/toolchain.txt"
printf '%s\n' "CARGO_TARGET_DIR=$CARGO_TARGET_DIR" "CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS" "CARGO_INCREMENTAL=$CARGO_INCREMENTAL" "CARGO_NET_OFFLINE=$CARGO_NET_OFFLINE" 'CUDARC_CUDA_VERSION=unset' 'RUSTC_WRAPPER=unset' 'RUSTC_WORKSPACE_WRAPPER=unset' 'CARGO_BUILD_RUSTC_WRAPPER=unset' 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER=unset' > "$record/build-environment.txt"
cmd=(taskset -c 10,11 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli
  --bin pancake-cli -j 2 --features cubecl/hip)
printf 'cwd=%q\n' "$PWD" > "$record/build.command"
printf '%q ' "${cmd[@]}" >> "$record/build.command"
printf '\n' >> "$record/build.command"
/usr/bin/time -v -o "$record/build-resources.txt" "${cmd[@]}" > "$record/build.log" 2>&1

cmd=(taskset -c 10,11 cargo +1.100.0 tree --locked --offline -p pancake-cli -e normal,build -i cubecl-hip --features cubecl/hip)
printf '%q ' "${cmd[@]}" > "$record/dependency-inverse.command"
printf '\n' >> "$record/dependency-inverse.command"
"${cmd[@]}" > "$record/dependency-inverse.txt" 2> "$record/dependency-inverse.stderr"
cmd=(taskset -c 10,11 cargo +1.100.0 tree --locked --offline -p pancake-cli -e normal,build --features cubecl/hip)
printf '%q ' "${cmd[@]}" > "$record/dependency-graph.command"
printf '\n' >> "$record/dependency-graph.command"
"${cmd[@]}" > "$record/dependency-graph.txt" 2> "$record/dependency-graph.stderr"
for required in cubecl-cpu cubecl-wgpu cubecl-hip cubecl-hip-sys; do
  grep -qF "$required v0.11.4" "$record/dependency-graph.txt"
done
if grep -Eq 'cubecl-(cuda|metal) v|cudarc v|slint v' "$record/dependency-graph.txt"; then
  printf '%s\n' 'Unexpected runtime or frontend in selected HIP graph'
  exit 1
fi

binary="$CARGO_TARGET_DIR/release/pancake-cli"
sha256sum "$binary" > "$record/binary.sha256"
stat -c '%s' "$binary" > "$record/binary.bytes"
file "$binary" > "$record/elf.txt"
readelf -W -h -n -d "$binary" > "$record/elf-static.txt"
nm --defined-only --demangle "$binary" | awk '
  /cubecl_hip/ { print; hip++ }
  /cubecl_cuda/ { cuda++ }
  /cubecl_wgpu/ { wgpu++ }
  /cubecl_cpu/ { cpu++ }
  END {
    print "symbol_counts: hip=" hip, "cuda=" (cuda+0), "wgpu=" wgpu, "cpu=" cpu
    exit !(hip>0 && cuda==0 && wgpu>0 && cpu>0)
  }
' > "$record/runtime-symbols.txt"
grep -Eq 'cubecl_hip::runtime|cubecl_hip::compute::server' "$record/runtime-symbols.txt"
{
  du -sb "$CARGO_TARGET_DIR"
  df -h "$PWD"
  free -h
} > "$record/host-resources.end.txt"
git status --porcelain=v1 > "$record/source-status.end.txt"
test -z "$(git status --porcelain=v1)"
sha256sum -c "$record/source-pin.sha256" > "$record/source-pin.verify.txt"

#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/hip-link"
test "$(git rev-parse HEAD)" = 0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
test -z "$(git status --porcelain=v1)"
cd "$root/pancake"
target="$PWD/target/native-hip-release"
grep -qF 'Exit status: 0' "$record/build-resources.txt"
grep -qE "Finished .release. profile" "$record/build.log"
for required in 'cubecl-cpu v0.11.4' 'cubecl-wgpu v0.11.4' 'cubecl-hip v0.11.4' 'cubecl-hip-sys v7.14.6085001'; do
  grep -qF "$required" "$record/dependency-graph.txt"
done
if grep -Eq 'cubecl-(cuda|metal) v|cudarc v|slint v' "$record/dependency-graph.txt"; then
  printf '%s\n' 'Unexpected optional runtime or frontend in selected HIP graph'
  exit 1
fi
grep -qF 'pancake-cli v0.1.0' "$record/dependency-inverse.txt"

shopt -s nullglob
abi=("$target"/release/build/cubecl-hip-sys/*/run/stdout)
test "${#abi[@]}" -eq 1
grep -F 'cargo:rustc-cfg=feature=' "${abi[0]}" > "$record/hip-abi.txt"
grep -qxF 'cargo:rustc-cfg=feature="hip_60850"' "$record/hip-abi.txt"
test "$(wc -l < "$record/hip-abi.txt")" -eq 1
cp "${abi[0]}" "$record/hip-sys-build-output.txt"

binary="$target/release/pancake-cli"
test -x "$binary"
sha256sum "$binary" > "$record/binary.sha256"
stat -c '%s' "$binary" > "$record/binary.bytes"
file "$binary" > "$record/elf.txt"
readelf -W -h -n -d "$binary" > "$record/elf-static.txt"
grep -F 'Build ID:' "$record/elf-static.txt" > "$record/elf-build-id.txt"
grep -F '(NEEDED)' "$record/elf-static.txt" > "$record/elf-needed.txt"
nm --defined-only --demangle "$binary" | awk '
  /cubecl_hip::/ { print; hip++ }
  /cubecl_hip_sys::/ { binding++ }
  /cubecl_cuda::/ { cuda++ }
  /cubecl_wgpu::/ { wgpu++ }
  /cubecl_cpu::/ { cpu++ }
  END {
    print "symbol_counts: hip=" hip, "hip_bindings=" binding, "cuda=" (cuda+0), "wgpu=" wgpu, "cpu=" cpu
    exit !(hip>0 && binding>0 && cuda==0 && wgpu>0 && cpu>0)
  }
' > "$record/runtime-symbols.txt"
grep -Eq 'cubecl_hip::runtime|cubecl_hip::compute::server' "$record/runtime-symbols.txt"
grep -q 'Advanced Micro Devices X86-64' "$record/elf-static.txt"
{
  du -sb "$target"
  df -h "$PWD"
  free -h
} > "$record/host-resources.end.txt"
git status --porcelain=v1 > "$record/source-status.end.txt"
test -z "$(git status --porcelain=v1)"
sha256sum -c "$record/source-pin.sha256" > "$record/source-pin.verify.txt"

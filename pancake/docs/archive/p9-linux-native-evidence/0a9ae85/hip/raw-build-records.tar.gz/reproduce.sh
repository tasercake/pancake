#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
record="$root/artifacts/hip-link"
test "$(git rev-parse HEAD)" = 0a9ae85b88519a795e3b6ba90860c3b3e664bcaa
test -z "$(git status --porcelain=v1)"
cd "$root/pancake"
unset CUDARC_CUDA_VERSION RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_TARGET_DIR="$PWD/target/native-hip-release"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
trap 'status=$?; date -u +%FT%TZ > "$record/end.txt"; printf "%s\n" "$status" > "$record/exit.txt"' EXIT
date -u +%FT%TZ > "$record/start.txt"
git rev-parse HEAD 'HEAD^{tree}' 'HEAD:pancake' > "$record/source-tree.txt"
git status --porcelain=v1 > "$record/source-status.start.txt"
sha256sum Cargo.lock Cargo.toml crates/pancake-cli/Cargo.toml > "$record/source-pin.sha256"
grep -qF 'f523404bf033b0532dc46ce71aa515dc398f56c32e6aee1c3529cf90a27018dc  Cargo.lock' "$record/source-pin.sha256"
{
  uname -srmo
  lscpu | grep -E '^Architecture|^CPU\(s\):|^Model name|^Thread\(s\) per core'
  taskset -c 10,11 bash -c "grep Cpus_allowed_list /proc/self/status"
  df -h "$PWD"
  free -h
} > "$record/host-resources.start.txt"
{
  cargo +1.100.0 -Vv
  rustc +1.100.0 -Vv
  cc --version
  ld --version
  nm --version
  readelf --version
} > "$record/toolchain.txt"
printf '%s\n' "CARGO_TARGET_DIR=$CARGO_TARGET_DIR" "CARGO_BUILD_JOBS=$CARGO_BUILD_JOBS" "CARGO_INCREMENTAL=$CARGO_INCREMENTAL" "CARGO_NET_OFFLINE=$CARGO_NET_OFFLINE" 'CUDARC_CUDA_VERSION=unset' 'RUSTC_WRAPPER=unset' 'RUSTC_WORKSPACE_WRAPPER=unset' 'CARGO_BUILD_RUSTC_WRAPPER=unset' 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER=unset' > "$record/build-environment.txt"
cmd=(taskset -c 10,11 cargo +1.100.0 build --locked --offline --release -p pancake -p pancake-cli
  --bin pancake-cli -j 2 --features cubecl/hip)
printf 'cwd=%q\n' "$PWD" > "$record/build.command"
printf '%q ' "${cmd[@]}" >> "$record/build.command"
printf '\n' >> "$record/build.command"
/usr/bin/time -v -o "$record/build-resources.txt" "${cmd[@]}" > "$record/build.log" 2>&1

bash "$record/record-graphs.sh"
bash "$record/verify-link.sh"

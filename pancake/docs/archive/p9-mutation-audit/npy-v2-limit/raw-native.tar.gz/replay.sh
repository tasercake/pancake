#!/usr/bin/env bash
set -euo pipefail
arm=${1:?red or green}
root="$PWD"
proof="$root/artifacts/npy-v2-limit-audit"
source="$root/pancake/src/image_io/npy.rs"
test -z "$(git status --porcelain=v1)"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="$root/pancake/target/npy-v2-limit" RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
if [[ $arm = red ]]; then
    cp "$source" "$proof/stock-npy.rs.txt"
    trap 'cp "$proof/stock-npy.rs.txt" "$source"' EXIT
    patch --batch --forward --fuzz=0 "$source" "$proof/survived.patch" > "$proof/red-apply.log"
    git diff -- pancake/src/image_io/npy.rs > "$proof/reproduced-mutant.patch"
fi
sha256sum "$source" "$root/pancake/Cargo.lock" "$root/pancake/tests/cpu_npy.rs" > "$proof/$arm-source.sha256"
cmd=(taskset --cpu-list 12,13 cargo +1.100.0 test --locked --offline -p pancake --test cpu_npy version_two_header_limit_is_inclusive -- --exact --test-threads=1)
printf '%q ' "${cmd[@]}" > "$proof/$arm.command"
printf '\n' >> "$proof/$arm.command"
status=0
(cd pancake && "${cmd[@]}") > "$proof/$arm.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/$arm.status"
tail -17 "$proof/$arm.log"
if [[ $arm = red ]]; then
    test "$status" -eq 101
    rg -q 'v2 payload at 65536 bytes:.*metadata limit' "$proof/$arm.log"
else
    test "$status" -eq 0
    rg -q '1 passed; 0 failed' "$proof/$arm.log"
fi

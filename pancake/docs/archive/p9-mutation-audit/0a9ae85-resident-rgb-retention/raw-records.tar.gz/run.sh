#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
base="$root/artifacts/resident-mutation"
out="$base/$1"
mkdir "$out"
cd "$root/pancake"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_BUILD_RUSTC_WRAPPER CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/target/resident-mutation"
git rev-parse HEAD 'HEAD^{tree}' > "$out/source.txt"
sha256sum Cargo.lock src/job/stream.rs tests/cpu_resident_policy.rs > "$out/pins.sha256"
git diff --binary -- src/job/stream.rs > "$out/applied.patch"
rustc +1.100.0 -Vv > "$out/rustc.txt"
cmd=(timeout --signal=TERM --kill-after=5s 540s taskset -c 14,15 cargo +1.100.0 test --locked --offline -p pancake --test cpu_resident_policy -- --exact configured_slabs_do_not_hold_the_registration_rgb)
printf '%s\n' "cwd=$PWD" "CARGO_TARGET_DIR=$CARGO_TARGET_DIR CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUSTC_WRAPPER=unset" > "$out/command.txt"
printf '%q ' "${cmd[@]}" >> "$out/command.txt"
printf '\n' >> "$out/command.txt"
trap 'status=$?; printf "%s\n" "$status" > "$out/exit.txt"; date -u +%FT%TZ > "$out/end.txt"' EXIT
/usr/bin/time -v -o "$out/resources.txt" "${cmd[@]}" > "$out/test.log" 2>&1

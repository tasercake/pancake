taskset -c 14\,15 cargo +1.100.0 clippy --locked --offline -p pancake --test cpu_resident_policy -- -D warnings 

#!/usr/bin/env bash
set -euo pipefail
arm=${1:?red or green}
root="$PWD"
proof="$root/artifacts/spectral-weak-peak-audit"
source="$root/pancake/src/registration/spectral.rs"
test -z "$(git status --porcelain=v1)"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="$root/pancake/target/spectral-weak-peak" RUSTC_WRAPPER=/tmp/pancake-tools/bin/pancake-rust-cache
if [[ $arm = red ]]; then
    cp "$source" "$proof/stock-spectral.rs.txt"
    trap 'cp "$proof/stock-spectral.rs.txt" "$source"' EXIT
    patch --batch --forward --fuzz=0 "$source" "$proof/survived.patch" > "$proof/red-apply.log"
    git diff -- pancake/src/registration/spectral.rs > "$proof/reproduced-mutant.patch"
fi
sha256sum "$source" "$root/pancake/Cargo.lock" "$root/pancake/assurance-platforms.json" > "$proof/$arm-source.sha256"
cmd=(taskset --cpu-list 12,13 cargo +1.100.0 test --locked --offline -p pancake --lib registration::spectral::tests::weak_spectral_peak_abstains_before_displacement -- --exact --test-threads=1)
printf '%q ' "${cmd[@]}" > "$proof/$arm.command"
printf '\n' >> "$proof/$arm.command"
status=0
(cd pancake && "${cmd[@]}") > "$proof/$arm.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$proof/$arm.status"
tail -17 "$proof/$arm.log"
if [[ $arm = red ]]; then
    test "$status" -eq 101
    rg -q 'spectral peak 204.75 returned Some\(\[-9.0, 10.0\]\), expected None' "$proof/$arm.log"
else
    test "$status" -eq 0
    rg -q '1 passed; 0 failed' "$proof/$arm.log"
fi

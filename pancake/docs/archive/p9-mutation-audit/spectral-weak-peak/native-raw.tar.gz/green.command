taskset --cpu-list 12\,13 cargo +1.100.0 test --locked --offline -p pancake --lib registration::spectral::tests::weak_spectral_peak_abstains_before_displacement -- --exact --test-threads=1 
